"""Manufacturer-neutral parsing. Detection never implies manufacturer verification."""
import re
from dataclasses import dataclass,asdict
@dataclass
class Identity:
    manufacturer:str
    family:str
    model:str
    dimension:str
    article_candidate:str
    article_status:str
    level:str
DIM=re.compile(r'(?<!\w)(?:DN\s*\d{1,4}|(?:Ø|ø)\s*\d+(?:[.,]\d+)?|\d{1,3}(?:[.,]\d+)?\s*[x×]\s*\d{1,3}(?:[.,]\d+)?|\d{1,3}\s*mm)(?!\w)',re.I)
EXPLICIT=re.compile(r'\b(?:Artikel(?:nummer|nr\.)?|Art\.?\s*Nr\.?|Bestell(?:nummer|nr\.)?|Order\s*(?:No|Number)|EAN)\s*[:#-]?\s*([A-Z0-9][A-Z0-9._/-]{3,24})',re.I)
def analyze(manufacturer,product,model='',article_no='',verified=False):
    manufacturer=str(manufacturer or '').strip()
    product=str(product or '').strip()
    model=str(model or '').strip()
    raw=str(article_no or '').strip()
    dim=DIM.search(' '.join((product,model)))
    match=EXPLICIT.search(' '.join((product,model)))
    candidate=raw or (match.group(1) if match else '')
    if candidate and not re.fullmatch(r'[A-Z0-9][A-Z0-9._/-]{3,24}',candidate,re.I):
        candidate=''
    # A type such as FK2-EU or SB-125-A is not promoted to an article number.
    status='verifiziert' if candidate and verified else ('Kandidat – Herstellerprüfung erforderlich' if candidate else 'keine Artikelnummer bestätigt')
    family=EXPLICIT.sub('',product).strip(' ,-;')
    level='Einzelartikel' if candidate and verified else ('Variante / Typ' if model or dim else 'Produktfamilie / System')
    return Identity(manufacturer,family,model,dim.group(0) if dim else '',candidate,status,level)
