import os
import tempfile
import time
import hashlib
import json
from pathlib import Path
import io, re, sqlite3, urllib.parse, os, hashlib
from urllib.parse import urljoin, urlparse
import pandas as pd
import requests
from bs4 import BeautifulSoup
import streamlit as st

# Dauerhafte Benutzerdaten liegen getrennt von den Programmdateien.
DATA_ROOT = os.environ.get('TGA_DATA_DIR') or os.path.join(os.environ.get('LOCALAPPDATA', os.path.expanduser('~')), 'TGA Product Finder', 'Data')
os.makedirs(DATA_ROOT, exist_ok=True)
DB = os.path.join(DATA_ROOT, 'tga_finder.db')
DOWNLOAD_ROOT = os.path.join(DATA_ROOT, 'offline_dokumente')
os.makedirs(DOWNLOAD_ROOT, exist_ok=True)
DOMAINS={'trox':'trox.de','rockwool':'rockwool.com','grohe':'grohe.de','geberit':'geberit.de'}
PRODUCTS={
 ('trox','FKRS-EU'):[
  'https://www.trox.de/brandschutzklappen/fkrs-eu-065efc2b4efeb254',
 ],
 ('trox','FK2-EU'):[
  'https://www.trox.de/brandschutzklappen/fk2-eu-d43c8f48f846955c',
  'https://www.trox.de/brand--und-rauchschutzsysteme/die-neue-brandschutzklappe-fk2-eu-02dbf47edadaf2f1',
 ],
 ('trox','TVE'):[
  'https://www.trox.de/vvs-regelgeraete/tve-3fb25f4ac74c6313',
 ],
 ('rockwool','800'):[
  'https://www.rockwool.com/de/produkte/rockwool-800/',
 ],
 ('rockwool','CONLIT U'):[
  'https://www.rockwool.com/de/produkte/conlit-150-u/',
  'https://dxp.rockwool.com/de/anwendungen/produktuebersicht/conlit-150-u/',
 ],
 ('rockwool','CONLIT 150 U'):[
  'https://www.rockwool.com/de/produkte/conlit-150-u/',
  'https://dxp.rockwool.com/de/anwendungen/produktuebersicht/conlit-150-u/',
 ],
}

ROCKWOOL_SPECIAL_SOURCES={
 'certificates':'https://www.rockwool.com/de/downloads-und-services/downloads/zertifikate/',
 'blue_angel':'https://www.rockwool.com/de/rat-und-tat/vertiefendes-wissen/umweltschutz-und-wohngesundheit/blauer-engel/',
}
ROCKWOOL_DOP_IDS={'800':'DE0721042201'}
ROCKWOOL_PRODUCT_PROOFS={'CONLIT U':'P-NDS04-417'}
ROCKWOOL_DIRECT_CERTIFICATES={
 '800':{
  'eurofins':'https://brandcommunity.rockwool.com/asset/ZxK0dbkv_tyZ8qJtpG6NVw/asset.pdf?quality=10',
  'blue_angel_registry':'https://www.blauer-engel.de/de/produkte/rockwool-daemmstoffe-fuer-technische-gebaeudeausruestung-gemaess-din-en-14303-rockwool-800-conlit-150u',
 },
 'CONLIT U':{
  'eurofins_page':'https://www.rockwool.com/de/downloads-und-services/downloads/zertifikate/',
  'eurofins_title':'Zertifikat Conlit 150 U Indoor Air Comfort Gold',
  'blue_angel_registry':'https://www.blauer-engel.de/de/produkte/rockwool-daemmstoffe-fuer-technische-gebaeudeausruestung-gemaess-din-en-14303-rockwool-800-conlit-150u',
 }
}



GROHE_VERIFIED_DOCS={
 '36327001':[
  {'Kategorie':'Produktdatenblatt','Priorität':'Empfohlen','Titel':'GROHE Product Datasheet 36327001','URL':'https://www.grohe.co.za/getmodule.php?id=pdf_generator.php&stock_code=GRO-G-36271000','Resolver':'GROHE verifizierter Online-Nachweis','Downloadbar':False,'Nachweis URL':'https://www.grohe.co.za/getmodule.php?id=pdf_generator.php&stock_code=GRO-G-36271000'},
  {'Kategorie':'Zulassung / Prüfzeugnis','Priorität':'Optional','Titel':'P-IX Prüfzeichen – PA-IX 16756/IO','URL':'https://cdn.cloud.grohe.com/Web/local_PDF/de_DE/P-IX_Pruefzeichen/original/P-IX_Pruefzeichen.pdf','Resolver':'GROHE Prüfzeichenregister · artikelbezogen verifiziert','Downloadbar':False,'Nachweis URL':'https://cdn.cloud.grohe.com/Web/local_PDF/de_DE/P-IX_Pruefzeichen/original/P-IX_Pruefzeichen.pdf'},
  {'Kategorie':'Broschüre / Planung','Priorität':'Optional','Titel':'GROHE Projekt 2024 – 36327001','URL':'https://cdn.cloud.grohe.com/Literature/Brochures/dk_DK/grohe_2024_DK_brochure_projekt_v2_LOW/original/grohe_2024_DK_brochure_projekt_v2_LOW.pdf','Resolver':'GROHE Projektunterlage'},
 ]
}


GEBERIT_VERIFIED_PRODUCTS={
 '501.632.00.1':{
  'name':'Geberit Renova Plan Waschtisch',
  'details':'55 cm · weiß · Hahnloch mittig · mit Überlauf',
  'page':'https://catalog.geberit.de/de-DE/product/PRO_1737077',
  'docs':[
   {'Kategorie':'Produktdatenblatt','Priorität':'Empfohlen','Titel':'Geberit Renova Plan – Produktdatenblatt 501.632.00.1','URL':'https://catalog.geberit.de/de-DE/product/PRO_1737077','Resolver':'Geberit Produktkatalog · verifizierter Online-Nachweis','Downloadbar':False,'Nachweis URL':'https://catalog.geberit.de/de-DE/product/PRO_1737077'},
  ]
 }
}


MAPRESS_THERM_GROUPS={
 'Systemrohr CrTi':{'details':'CrTi-Stahl 1.4520 · DN 12–100 · d15–108 mm','page':'https://catalog.geberit.de/de-DE/product/PRO_3207998'},
 'Fitting / Formstück':{'details':'Pressfittings · Dokumentgruppe wird nach Bauform gewählt; Dimension ist für die Dokumentmappe nicht erforderlich','page':'https://www.geberit.de/sanitaer-rohrleitungssysteme/versorgungssysteme/geberit-mapress/geberit-mapress-therm/'},
}

MAPRESS_THERM_FITTINGS={
 'Muffe':{
  'page':'https://catalog.geberit.de/de-DE/product/PRO_3207533',
  'docs':[
   {'Kategorie':'Produktdatenblatt','Priorität':'Empfohlen','Titel':'Geberit Mapress Therm Muffe – Produktdatenblatt','Resolver':'Geberit Produktkatalog · verifizierter Online-Nachweis'},
   {'Kategorie':'EPD / DGNB / Umwelt','Priorität':'Empfohlen','Titel':'Geberit Mapress Therm Muffe – Umweltproduktdeklaration','Resolver':'Geberit Produktkatalog · EPD-Nachweis'},
  ],
  'variants':{
   'd15 / DN12':'44002','d18 / DN15':'44003','d22 / DN20':'44004','d28 / DN25':'44005','d35 / DN32':'44006',
   'd42 / DN40':'44007','d54 / DN50':'44008','d76,1 / DN65':'44009','d88,9 / DN80':'44010','d108 / DN100':'44011',
  }
 },
 'Schiebemuffe':{
  'page':'https://catalog.geberit.de/de-DE/product/PRO_3207553',
  'docs':[
   {'Kategorie':'Produktdatenblatt','Priorität':'Empfohlen','Titel':'Geberit Mapress Therm Schiebemuffe – Produktdatenblatt','Resolver':'Geberit Produktkatalog · verifizierter Online-Nachweis'},
   {'Kategorie':'EPD / DGNB / Umwelt','Priorität':'Empfohlen','Titel':'Geberit Mapress Therm Schiebemuffe – Umweltproduktdeklaration','Resolver':'Geberit Produktkatalog · EPD-Nachweis'},
  ],
  'variants':{
   'd15 / DN12':'42102','d18 / DN15':'42103','d22 / DN20':'42104','d28 / DN25':'42105','d35 / DN32':'42106',
   'd42 / DN40':'42107','d54 / DN50':'42108','d76,1 / DN65':'42109','d88,9 / DN80':'42110','d108 / DN100':'42111',
  }
 },
}

def is_geberit_mapress_therm(manufacturer, product):
 return 'geberit' in clean(manufacturer).lower() and 'MAPRESS THERM' in clean(product).upper()

def mapress_group_label(group):
 v=MAPRESS_THERM_GROUPS[group]
 return f"{group} — {v['details']}"

def is_geberit_verified(manufacturer, article):
 return 'geberit' in clean(manufacturer).lower() and clean(article) in GEBERIT_VERIFIED_PRODUCTS

def find_geberit_docs(article):
 article=clean(article)
 cfg=GEBERIT_VERIFIED_PRODUCTS.get(article)
 if not cfg: raise ValueError('Diese Geberit-Artikelnummer ist in v0.6.0 noch nicht automatisch freigeschaltet.')
 docs=[]
 for d in cfg['docs']:
  row=dict(d); row.update({'Treffer %':100,'Quellseite':cfg['page'],'Relevant':True}); row.setdefault('Nachweis URL',''); docs.append(row)
 return cfg['page'],docs

GROHE_VARIANTS={
 '36324001':{'name':'Eurosmart CE · Waschtisch · Niederdruck','details':'Niederdruck / offener Warmwasserbereiter · Netzbetrieb · mit Mischung'},
 '36325001':{'name':'Eurosmart CE · Waschtisch · Netzbetrieb','details':'Hochdruck · Steckertrafo 100–240 V · Sensor · mit Mischung'},
 '36327001':{'name':'Eurosmart CE · Waschtisch · Batteriebetrieb','details':'Hochdruck · 6-V-Batterie · Sensor · mit Mischung'},
 '36331001':{'name':'Eurosmart CE · Waschtisch · Batteriebetrieb','details':'Sensor · 6-V-Batterie · Waschtisch-Ausführung'},
 '36332000':{'name':'Eurosmart CE · Waschtisch-Wandarmatur','details':'Wandmontage · mit Mischeinrichtung und Thermostat · 6-V-Batterie'},
}

def is_grohe_eurosmart_ce(manufacturer, product):
 return 'grohe' in clean(manufacturer).lower() and 'EUROSMART CE' in clean(product).upper()

def grohe_variant_label(article):
 v=GROHE_VARIANTS[article]
 return f"{article} — {v['name']} — {v['details']}"

CATS=['Produktdatenblatt','Planung & Montage','Montage – Sonderanwendung','Leistungserklärung (DoP)','CE / Konformität','ATEX','Hygiene','Zulassung / Prüfzeugnis','EPD / DGNB / Umwelt','Broschüre / Planung','Sonstiges']

def helios_official_article(manufacturer, product, model_type='', article_no=''):
 if 'helios' not in str(manufacturer or '').casefold(): return None
 text=' '.join(str(v or '') for v in (product,model_type))
 variants={re.sub(r'\s+','',v.upper()) for v in re.findall(r'(?<![A-Za-z0-9])SB\s*\d+\s*[A-Z](?![A-Za-z0-9])',text,re.I)}
 if variants!={'SB125A'}: return None
 existing=str(article_no or '').strip()
 return {'article':'09506','conflict':bool(existing and existing.lstrip('0')!='9506'),'source':'https://www.helios.ch/de/produkt/sb-125-a-silentbox-rohrventilator-1-ph-schallgedaempft'}

def classify_component_identifier(manufacturer, product, value):
 import re
 maker=str(manufacturer or '').strip().casefold()
 raw=str(value or '').strip()
 normalized=re.sub(r'\s+',' ',raw.upper())
 if not normalized:return ('','','empty')
 series=('DUOFIX','NEWO','PRO LIBERTY','B.2','KEUCO PLAN','ART','PROFIPRESS','HT-SAFE','MAPRESS EDELSTAHL','FILLSET COMPACT')
 if any(normalized==v or normalized.startswith(v+' ') for v in series):
  return ('','','family')
 # A prefixed part number must contain a complete number, not a truncated UI value.
 prefixed=re.fullmatch(r'(?:ARTIKEL[- ]?NR\.?|ART\.?[- ]?NR\.?)\s*[:.]?\s*(\d{3}(?:\.\d{1,3}){2,3})',normalized)
 if prefixed:
  return ('',prefixed.group(1),'article')

 # Known TGA family designations are never exact article numbers.
 family_terms=('PROFIPRESS','HT-SAFE','MAPRESS EDELSTAHL','FILLSET COMPACT')
 if any(normalized==term or normalized.startswith(term+' ') for term in family_terms):
  return ('','','family')
 # Product types: code shapes and common manufacturer-neutral model notation.
 if re.fullmatch(r'(?:BASIC[- ]?[A-Z]|U\d[A-Z]|TD[- ]?Z\s*\d+(?:[-/]\d+){1,4}|FIGUR\s*\d+\s*[A-Z0-9]*)',normalized):
  return (normalized,'','type')

 # Numerische Bestellnummern nicht automatisch in Typen umwandeln.
 if re.fullmatch(r'\d{5,}(?:[.\-]\d+)*',normalized):return ('',raw,'article')
 if 'helios' in maker and re.fullmatch(r'(?:SB|SVS|RR|K|ELS|PA)\s*[-/]?\s*\d{2,4}(?:\s*[-/]?\s*[A-Z0-9]{1,4})?',normalized):
  return (normalized,'','type')
 if 'trox' in maker and re.fullmatch(r'(?:FKRS-EU|FK2-EU|TVE|FV-EU|VFL)(?:[/\-][A-Z0-9]+)*',normalized):
  return (normalized,'','type')
 if re.fullmatch(r"\d{3}(?:\.\d{1,3}){2,3}",normalized):
  return ("",raw,"article")
 if 'lunos' in maker and normalized in ('3/UP','V-EC'):
  return (normalized,'','type')
 if 'trox' in maker and normalized=='LVS':
  return (normalized,'','type')
 if 'danfoss' in maker and re.fullmatch(r'ECL\s+COMFORT\s+310',normalized):
  return (normalized,'','type')
 if 'reflex' in maker and (re.fullmatch(r'N\s*\d{2,4}',normalized) or re.fullmatch(r'SERVITEC\s+[A-Z0-9-]+',normalized)):
  return (normalized,'','type')
 if 'reflex' in maker and normalized.startswith('FILLSET COMPACT'):
  return ('', '', 'family')
 if 'wika' in maker and re.fullmatch(r'\d{3}\.\d{2}\s+NG\s*\d{2,3}',normalized):
  return (normalized,'','type')
 if 'viega' in maker and normalized=='PROFIPRESS':
  return ('','','family')
 if 'rockwool' in maker and re.fullmatch(r'(?:CONLIT\s*150\s*U|800)',normalized):
  return (normalized,'','type')
 # Typische technische Typcodes mit Buchstaben und Ziffern, aber nur
 # wenn ein deutliches Modellpraefix vorhanden ist; sonst offen lassen.
 if re.fullmatch(r'[A-Z]{2,8}[- ]?\d{2,5}(?:[- /][A-Z0-9]{1,6}){0,3}',normalized):
  return (normalized,'','type_candidate')
 return ('',raw,'unclassified')

def db():
 c=sqlite3.connect(DB)
 c.execute('CREATE TABLE IF NOT EXISTS components(id INTEGER PRIMARY KEY, project TEXT, manufacturer TEXT, product TEXT, article_no TEXT, confidence INTEGER, status TEXT, docs_searched INTEGER DEFAULT 0)')
 c.execute('CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY, component_id INTEGER, doc_type TEXT, title TEXT, source_url TEXT, verified INTEGER DEFAULT 0, confidence INTEGER DEFAULT 0, source_page TEXT DEFAULT "", local_path TEXT DEFAULT "", download_status TEXT DEFAULT "", priority TEXT DEFAULT "")')
 c.execute('CREATE TABLE IF NOT EXISTS component_selections(component_id INTEGER, selection TEXT, PRIMARY KEY(component_id,selection))')
 c.execute('CREATE TABLE IF NOT EXISTS component_application_groups(component_id INTEGER, group_code TEXT, PRIMARY KEY(component_id,group_code))')
 try:
  c.execute('ALTER TABLE components ADD COLUMN gewerk TEXT')
 except Exception as exc:
  if 'duplicate column name' not in str(exc).lower(): raise
 c.execute('CREATE TABLE IF NOT EXISTS projects(name TEXT PRIMARY KEY, created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
 c.execute('INSERT OR IGNORE INTO projects(name) SELECT DISTINCT project FROM components WHERE project IS NOT NULL AND TRIM(project) != ""')
 ccols={r[1] for r in c.execute('PRAGMA table_info(components)').fetchall()}
 if 'docs_searched' not in ccols: c.execute('ALTER TABLE components ADD COLUMN docs_searched INTEGER DEFAULT 0')
 if 'manufacturer_product_name' not in ccols: c.execute('ALTER TABLE components ADD COLUMN manufacturer_product_name TEXT DEFAULT ""')
 if 'model_type' not in ccols: c.execute('ALTER TABLE components ADD COLUMN model_type TEXT DEFAULT ""')
 if 'identifier_source' not in ccols: c.execute('ALTER TABLE components ADD COLUMN identifier_source TEXT DEFAULT ""')
 if 'product_family' not in ccols: c.execute('ALTER TABLE components ADD COLUMN product_family TEXT DEFAULT ""')
 if 'documentation_scope' not in ccols: c.execute('ALTER TABLE components ADD COLUMN documentation_scope TEXT DEFAULT "Produktfamilie"')
 if 'component_category' not in ccols: c.execute('ALTER TABLE components ADD COLUMN component_category TEXT DEFAULT ""')
 if 'dimensions_grouped' not in ccols: c.execute('ALTER TABLE components ADD COLUMN dimensions_grouped TEXT DEFAULT ""')
 for _cid,_maker,_product,_article,_model in c.execute('SELECT id,manufacturer,product,article_no,model_type FROM components').fetchall():
  if str(_article or '').strip():
   c.execute('UPDATE components SET identifier_source=? WHERE id=? AND (identifier_source IS NULL OR identifier_source=?)',(_article,_cid,''))
  _type,_article_clean,_kind=classify_component_identifier(_maker,_product,_article)
  if _kind=='family' and str(_article or '').strip():
   c.execute('UPDATE components SET product_family=?,article_no=? WHERE id=?',(_article,'',_cid))
  if _kind in ('type','type_candidate') and not str(_model or '').strip():
   c.execute('UPDATE components SET model_type=?,article_no=? WHERE id=?',(_type,_article_clean,_cid))
 if 'product_name_confirmed' not in ccols: c.execute('ALTER TABLE components ADD COLUMN product_name_confirmed INTEGER DEFAULT 0')
 cols={r[1] for r in c.execute('PRAGMA table_info(documents)').fetchall()}
 for name,sql in [('confidence','INTEGER DEFAULT 0'),('source_page','TEXT DEFAULT ""'),('local_path','TEXT DEFAULT ""'),('download_status','TEXT DEFAULT ""'),('priority','TEXT DEFAULT ""'),('project_confirmed','INTEGER DEFAULT 0'),('project_decision','TEXT DEFAULT ""'),('project_decision_note','TEXT DEFAULT ""')]:
  if name not in cols: c.execute(f'ALTER TABLE documents ADD COLUMN {name} {sql}')
 c.execute("UPDATE documents SET project_confirmed=0 WHERE title LIKE '%Mapress Therm%Installation / Verarbeitung%' AND project_confirmed=1 AND (project_decision IS NULL OR project_decision='')")
 c.execute("UPDATE documents SET project_confirmed=0,project_decision='',project_decision_note='' WHERE title='Anwendbarkeitsnachweise' AND project_decision='manual_confirmed'")
 c.commit(); return c

def persist_search_docs(con, component_id, docs):
 # Suchergebnisse projektweit speichern. Bereits getroffene Projektbestätigungen bleiben bei erneuter Suche erhalten.
 confirmed_before={(r[0],r[1]):(r[2],r[3],r[4]) for r in con.execute('SELECT title,source_url,project_confirmed,project_decision,project_decision_note FROM documents WHERE component_id=?',(component_id,)).fetchall()}
 con.execute('UPDATE components SET docs_searched=1 WHERE id=?',(component_id,))
 con.execute("DELETE FROM documents WHERE component_id=? AND (local_path IS NULL OR local_path='')",(component_id,))
 for d in docs:
  if not d.get('Relevant'): continue
  online=not d.get('Downloadbar',True)
  verified=1 if online else 0
  dstatus='Online-Nachweis' if online else 'Fundstelle gefunden'
  title=d.get('Titel','Dokument'); url=d.get('URL',''); confirmed,decision,note=confirmed_before.get((title,url),(0,'',''))
  con.execute('INSERT INTO documents(component_id,doc_type,title,source_url,verified,confidence,source_page,local_path,download_status,priority,project_confirmed,project_decision,project_decision_note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(component_id,d.get('Kategorie','Sonstiges'),title,url,verified,d.get('Treffer %',0),d.get('Quellseite',''),'',dstatus,d.get('Priorität',''),confirmed,decision,note))
 con.commit()

def get_component_selections(con, component_id):
 return [r[0] for r in con.execute('SELECT selection FROM component_selections WHERE component_id=? ORDER BY selection',(component_id,)).fetchall()]

def save_component_selections(con, component_id, selections):
 con.execute('DELETE FROM component_selections WHERE component_id=?',(component_id,))
 for sel in selections:
  con.execute('INSERT OR IGNORE INTO component_selections(component_id,selection) VALUES(?,?)',(component_id,sel))
 con.commit()

def get_application_groups(con, component_id):
 return [r[0] for r in con.execute('SELECT group_code FROM component_application_groups WHERE component_id=? ORDER BY group_code',(component_id,)).fetchall()]

def save_application_groups(con, component_id, group_codes):
 con.execute('DELETE FROM component_application_groups WHERE component_id=?',(component_id,))
 for code in group_codes:
  con.execute('INSERT OR IGNORE INTO component_application_groups(component_id,group_code) VALUES(?,?)',(component_id,code))
 con.commit()

def ensure_conlit_proofs(con, project, component_id, manufacturer, product, selected_labels):
 """Ordnet die offiziellen ROCKWOOL-Nachweise zu und speichert sie offline.
 Gibt (erfolgreiche_labels, fehler) zurück.
 """
 headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36'}
 ok=[]; errors=[]
 for label in selected_labels:
  cfg=CONLIT_DOCUMENT_GROUPS[label]; url=cfg['url']; proof=cfg['proof']
  title=f'ROCKWOOL Conlit 150 U – {proof}'
  existing=con.execute('SELECT id,local_path FROM documents WHERE component_id=? AND title=?',(component_id,title)).fetchone()
  if existing and existing[1] and os.path.exists(existing[1]):
   ok.append(label); continue
  try:
   r=requests.get(url,headers=headers,timeout=60,allow_redirects=True); r.raise_for_status()
   if not allowed_download(r.url,'rockwool') or not is_pdf_response(r):
    raise ValueError('Herstellerquelle liefert aktuell keine PDF.')
   folder=os.path.join(DOWNLOAD_ROOT,safe(project),safe(manufacturer),safe(CONLIT_OFFICIAL_NAME)); os.makedirs(folder,exist_ok=True)
   filename=safe(proof)+'.pdf'; path=os.path.join(folder,filename)
   with open(path,'wb') as fh: fh.write(r.content)
   con.execute('DELETE FROM documents WHERE component_id=? AND title=?',(component_id,title))
   con.execute('INSERT INTO documents(component_id,doc_type,title,source_url,verified,confidence,source_page,local_path,download_status,priority,project_confirmed,project_decision,project_decision_note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
    (component_id,'Zulassung / Prüfzeugnis',title,url,1,100,'ROCKWOOL · offizieller Anwendbarkeitsnachweis',path,f'Offline · {len(r.content)/1024/1024:.1f} MB','Empfohlen',0,cfg['code'],f'Dokumentgruppe: {label}'))
   ok.append(label)
  except Exception as e:
   errors.append(f'{proof}: {e}')
 con.commit(); return ok,errors

def mapress_selection_docs(selections):
 docs=[]; pages=[]
 install='https://www.geberit.de/sanitaer-rohrleitungssysteme/versorgungssysteme/geberit-mapress/geberit-mapress-therm/'
 for sel in selections:
  if sel=='Systemrohr CrTi':
   cfg=MAPRESS_THERM_GROUPS['Systemrohr CrTi']; pages.append(cfg['page'])
   docs.append({'Kategorie':'Produktdatenblatt','Priorität':'Empfohlen','Titel':'Geberit Mapress Therm Systemrohr CrTi – Produktdatenblatt','Resolver':'Geberit Produktkatalog · verifizierter Online-Nachweis','URL':cfg['page'],'Quellseite':cfg['page'],'Treffer %':100,'Relevant':True,'Downloadbar':False,'Nachweis URL':cfg['page']})
  elif sel in MAPRESS_THERM_FITTINGS:
   cfg=MAPRESS_THERM_FITTINGS[sel]; pages.append(cfg['page'])
   for base in cfg.get('docs',[]):
    d=dict(base); d.update({'URL':cfg['page'],'Quellseite':cfg['page'],'Treffer %':100,'Relevant':True,'Downloadbar':False,'Nachweis URL':cfg['page']}); docs.append(d)
 if selections:
  docs.append({'Kategorie':'Planung & Montage','Priorität':'Anwendungsfall prüfen','Titel':'Geberit Mapress Therm – Installation / Verarbeitung','Resolver':'Geberit Systeminformation · d108 abweichend','URL':install,'Quellseite':install,'Treffer %':100,'Relevant':True,'Downloadbar':False,'Nachweis URL':install})
 # identische Dokumente aus mehreren Teilkomponenten nur einmal führen
 unique=[]; seen=set()
 for d in docs:
  key=(d.get('Kategorie'),d.get('Titel'),d.get('URL'))
  if key not in seen: seen.add(key); unique.append(d)
 return (pages[0] if pages else install),unique

def documentation_light(searched, docs):
 if not searched:
  return '🔴 Noch nicht bearbeitet'
 if not docs:
  return '🟡 Suche ausgeführt · kein Nachweis'
 # docs: priority, verified, local_path, download_status, project_confirmed
 checks=sum(1 for prio,_,_,_,confirmed in docs if prio in ['Anwendungsfall prüfen','Optional / Ausführung prüfen'] and not confirmed)
 recommended=sum(1 for prio,_,_,_,_ in docs if prio=='Empfohlen')
 if checks or recommended==0:
  return '🟡 Prüfung/offene Unterlagen'
 return '🟢 Dokumentation geklärt'

def clean(v):
 if pd.isna(v): return ''
 return re.sub(r'\s+',' ',str(v)).strip()

def detect_header(raw):
 aliases={
  'hersteller': {'hersteller','hersteller/fabrikat','fabrikat'},
  'bezeichnung': {'bezeichnung','produkt/bezeichnung','produkt','produktbezeichnung'},
  'artikelnummer': {'artikelnummer','typ/modell','typ','modell','artikel-nr.','artikel-nr'},
  'gewerk': {'gewerk'}
 }
 def normalize(x):
  return re.sub(r'\s*[/]\s*','/',clean(x).lower()).strip(' :')
 for i,row in raw.head(40).iterrows():
  values={normalize(x) for x in row.tolist()}
  if len(values & aliases['bezeichnung'])>=1 and len(values & (aliases['hersteller']|aliases['artikelnummer']))>=1:
   return i
 raise ValueError('Keine passende Kopfzeile gefunden. Erwartet: Produkt/Bezeichnung und Hersteller/Fabrikat oder Typ/Modell.')

def read_excel(data):
 raw=pd.read_excel(io.BytesIO(data),header=None)
 h=detect_header(raw)
 df=pd.read_excel(io.BytesIO(data),header=h).dropna(axis=1,how='all').dropna(axis=0,how='all')
 aliases={
  'Hersteller':['hersteller','hersteller/fabrikat','fabrikat'],
  'Bezeichnung':['bezeichnung','produkt/bezeichnung','produkt','produktbezeichnung'],
  'Typ / Modell':['typ/modell','typ','modell','typbezeichnung','modellbezeichnung'],
  'Artikelnummer':['artikelnummer','artikel-nr.','artikel-nr','art.-nr.','art.-nr','bestellnummer','bestell-nr.','materialnummer'],
  'Gewerk':['gewerk']
 }
 def normalize(x):return re.sub(r'\s*[/]\s*','/',clean(x).lower()).strip(' :')
 cols={normalize(c):c for c in df.columns}
 out=pd.DataFrame()
 for target,choices in aliases.items():
  col=next((cols[c] for c in choices if c in cols),None)
  out[target]=df[col].map(clean) if col is not None else ''
 out=out[(out.Hersteller!='')|(out.Bezeichnung!='')].reset_index(drop=True)
 if out.empty:raise ValueError('Keine Produktzeilen gefunden.')
 return out

def score(r):
 base=min(45+(20 if r['Hersteller'] else 0)+(20 if r['Bezeichnung'] else 0)+(15 if r['Artikelnummer'] or r.get('Typ / Modell','') else 0),100)
 kind=classify_component_identifier(r['Hersteller'],r['Bezeichnung'],r['Artikelnummer'])[2]
 return min(base,85) if r['Artikelnummer'] and kind=='unclassified' else base
 def status(s): return 'Automatisch prüfbar' if s>=95 else ('Bestätigung empfohlen' if s>=75 else 'Manuelle Prüfung')
def safe(v): return (re.sub(r'[^A-Za-z0-9ÄÖÜäöüß._-]+','_',clean(v)).strip('._')[:120] or 'dokument')

def product_key(m,p):
 ml=clean(m).lower(); pu=clean(p).upper()
 # Herstellerbezeichnungen aus Excel dürfen Zusätze enthalten.
 if 'rockwool' in ml: ml='rockwool'
 elif 'trox' in ml: ml='trox'
 # Unterstützte ROCKWOOL-Produktfamilien robust normalisieren.
 if ml=='rockwool':
  if 'CONLIT' in pu and ('150 U' in pu or pu.endswith(' U') or pu=='CONLIT U'): return (ml,'CONLIT U')
  if re.search(r'(^|\D)800($|\D)', pu): return (ml,'800')
 return (ml,pu)

def is_rockwool_conlit(manufacturer, product):
 return 'rockwool' in clean(manufacturer).lower() and product_key(manufacturer,product)[1]=='CONLIT U'

def is_trox_fk2(manufacturer, product):
 return clean(manufacturer).lower()=='trox' and clean(product).upper()=='FK2-EU'

FK2_APPLICATION_GROUPS={
 'fk2_standard':'Standardanwendung',
 'fk2_atex':'ATEX / explosionsgefährdeter Bereich',
 'fk2_special_mounting':'Montage-Sonderanwendung',
}

def fk2_check_group(doc_type):
 if doc_type=='ATEX': return 'fk2_atex'
 if doc_type=='Montage – Sonderanwendung': return 'fk2_special_mounting'
 return ''

def _fk2_version_key(title):
 # Neueste Fassung aus TROX-Dateinamen bevorzugen (z. B. V3_2025_08 bzw. 2022_07_06).
 t=clean(title)
 dates=re.findall(r'(20\d{2})[_-](\d{2})(?:[_-](\d{2}))?',t)
 date=max(((int(y),int(m),int(d or 0)) for y,m,d in dates),default=(0,0,0))
 vm=re.search(r'(?:^|[_-])V(\d+)(?:[_-]|\.)',t,re.I)
 version=int(vm.group(1)) if vm else 0
 return date+(version,)

def fk2_required_group_rows(rows, group_code):
 relevant=[r for r in rows if fk2_check_group(r[1])==group_code]
 if group_code!='fk2_atex': return relevant
 # ATEX besteht aus Rollen, nicht aus allen historischen Dateien:
 # 1) aktuelle ATEX-Betriebs-/Zusatzanleitung, 2) aktuelle CE/ATEX-Konformitätsunterlage.
 manuals=[r for r in relevant if 'A000' in clean(r[2]).upper() or re.search(r'(?:^|[_-])V\d+',clean(r[2]),re.I)]
 conformity=[r for r in relevant if 'CE' in clean(r[2]).upper() and 'ATEX' in clean(r[2]).upper()]
 required=[]
 if manuals: required.append(max(manuals,key=lambda r:_fk2_version_key(r[2])))
 if conformity: required.append(max(conformity,key=lambda r:_fk2_version_key(r[2])))
 # Fallback für unerwartete TROX-Namensänderungen: mindestens den neuesten ATEX-Treffer verlangen.
 if not required and relevant: required=[max(relevant,key=lambda r:_fk2_version_key(r[2]))]
 seen=set(); out=[]
 for r in required:
  if r[0] not in seen: out.append(r); seen.add(r[0])
 return out

def fk2_group_complete(rows, group_code):
 required=fk2_required_group_rows(rows,group_code)
 if not required: return False
 return all(bool((r[5] and os.path.exists(r[5])) or r[6]=='Online-Nachweis') for r in required)

def save_fk2_application(con, component_id, selected_codes, saved_rows):
 # Standard ist immer die Basis; gespeichert werden nur die zusätzlich benötigten Dokumentgruppen.
 save_application_groups(con,component_id,['fk2_standard']+list(selected_codes))
 required_ids={g:{r[0] for r in fk2_required_group_rows(saved_rows,g)} for g in selected_codes}
 for r in saved_rows:
  docid,dtype,title,url,dconf,path,dstatus,prio,confirmed,source_page,decision,note=r
  group=fk2_check_group(dtype)
  if not group: continue
  if group not in selected_codes:
   con.execute('UPDATE documents SET project_confirmed=1,project_decision=?,project_decision_note=? WHERE id=?',
    ('fk2_not_required','Für dieses Projekt nicht ausgewählt; Standardanwendung bzw. andere Dokumentgruppe maßgeblich.',docid))
  elif docid not in required_ids.get(group,set()):
   con.execute('UPDATE documents SET project_confirmed=1,project_decision=?,project_decision_note=? WHERE id=?',
    ('fk2_superseded','Ältere bzw. zusätzliche Fassung; für die Vollständigkeit wird die aktuelle erforderliche Dokumentrolle bewertet.',docid))
  else:
   available=bool((path and os.path.exists(path)) or dstatus=='Online-Nachweis')
   con.execute('UPDATE documents SET project_confirmed=?,project_decision=?,project_decision_note=? WHERE id=?',
    (1 if available else 0,'fk2_group_complete' if available else 'fk2_group_required',
     f'Dokumentgruppe {FK2_APPLICATION_GROUPS[group]} ist projektbezogen ausgewählt.' + (' Aktueller Nachweis ist vorhanden.' if available else ' Aktueller Nachweis muss noch offline gespeichert oder verifiziert werden.'),docid))
 con.commit()


CONLIT_OFFICIAL_NAME='ROCKWOOL Conlit® 150 U'
# Nur dokumentationsrelevante Gruppen: Varianten werden zusammengefasst, wenn dieselben Nachweise gelten.
CONLIT_DOCUMENT_GROUPS={
 'Nichtbrennbare Versorgungs-/Rohrleitungen (einschl. metallische Gasleitungen)':{
  'code':'conlit_noncombustible','proof':'abP P-3725/4130-MPA BS','url':'https://www.rockwool.com/siteassets/rw-d/prufzeugnisse/rohrleitungen/pz-abp-conlit-150u-nichtbrennbare-rohrleitungen-r90-rockwool.pdf',
  'note':'Dokumentgruppe für nichtbrennbare Rohrleitungen; metallische Gasleitungen werden nicht separat angeboten, weil sie derselben Nachweisgruppe zugeordnet werden.'},
 'Brennbare Versorgungsleitungen':{
  'code':'conlit_combustible_supply','proof':'abP P-3726/4140-MPA BS','url':'https://www.rockwool.com/siteassets/rw-d/prufzeugnisse/rohrleitungen/pz-abp-conlit-150u-brennbare-rohrleitungen-r90-rockwool.pdf',
  'note':'Eigene Dokumentgruppe für brennbare Versorgungsleitungen.'},
 'Mischinstallationen bei Versorgungsleitungen':{
  'code':'conlit_mixed','proof':'aBG Z-19.53-2426','url':'https://www.rockwool.com/syssiteassets/rw-d/prufzeugnisse/rohrleitungen/pz-abg-rohrabschottung-r90-fuer-mischinstallationen-bei-versorgungsleitungen-rockwool.pdf',
  'note':'Eigene Dokumentgruppe für Mischinstallationen bei Versorgungsleitungen.'},
 'Brennbare Gasrohrleitungen (Kunststoff / Mehrschichtverbund)':{
  'code':'conlit_combustible_gas','proof':'aBG Z-19.53-2436','url':'https://www.rockwool.com/syssiteassets/rw-d/prufzeugnisse/rohrleitungen/pz-rohrab-kunststoff-gasrohrleitungen-conlit-150u-schale-rockwool.pdf',
  'note':'Eigene Dokumentgruppe für brennbare Gasrohrleitungen; zusätzliche Randbedingungen des Nachweises sind zu beachten.'},
}

def classify(title,url,manufacturer):
 b=(title+' '+url).lower()
 if 'atex' in b:return 'ATEX'
 if any(x in b for x in ['_dop_','leistungserklärung','declaration-of-performance','declaration of performance']):return 'Leistungserklärung (DoP)'
 if any(x in b for x in ['hygiene','hygien','_hc_']):return 'Hygiene'
 if any(x in b for x in ['epd','environmental product','dgnb','blauer-engel','eurofins','indoor-air']):return 'EPD / DGNB / Umwelt'
 if any(x in b for x in ['datenblatt','produktdatenblatt','datasheet','data-sheet','_pd_','db-']):return 'Produktdatenblatt'
 # Eindeutige CE-Dateinamen vor generischen Zertifikatsbegriffen prüfen.
 if any(x in b for x in ['konform','conform','_ce_','ce-']) and 'atex' not in b:return 'CE / Konformität'
 if any(x in b for x in ['abp','abg','zulassung','bauartgenehmigung','anwendbarkeitsnachweis','prüfzeugnis','prufzeugnis','dibt','zertifikat','certificate']):return 'Zulassung / Prüfzeugnis'
 if any(x in b for x in ['montage','installation','betriebsanleitung','operating','_iom_']):
  if manufacturer=='trox' and any(x in b for x in ['_gl_','_glk_','_wa_','_we_','_oda_','rm-o','_sv_','_e3_','_ew_']):return 'Montage – Sonderanwendung'
  return 'Planung & Montage'
 if re.search(r'(^|[/_-])lc([_.-]|$)', b):return 'Sonstiges'
 if any(x in b for x in ['broschüre','broschuere','brochure','planungs','ratgeber','handbuch']):return 'Broschüre / Planung'
 return 'Sonstiges'

def priority(cat,title,url,manufacturer,product):
 b=(title+' '+url).lower()
 if cat in ['Produktdatenblatt','Leistungserklärung (DoP)','CE / Konformität','Hygiene','EPD / DGNB / Umwelt']: return 'Empfohlen'
 if cat=='Planung & Montage': return 'Empfohlen'
 if cat in ['ATEX','Montage – Sonderanwendung']: return 'Optional / Ausführung prüfen'
 if cat=='Zulassung / Prüfzeugnis': return 'Anwendungsfall prüfen' if manufacturer=='rockwool' else 'Empfohlen'
 if cat=='Broschüre / Planung': return 'Optional'
 return 'Optional'

def relevance(product,title,url):
 b=(title+' '+url).lower(); p=product.lower()
 aliases=[p]
 if p=='conlit u': aliases+=['conlit 150 u','conlit-150-u','conlit-150u']
 if p=='800': aliases+=['rockwool 800','rockwool-800']
 return any(a in b for a in aliases)

MANUFACTURER_SEARCH_RULES={
 'trox':{'domain':'trox.de','strategy':'official_product_page'},
 'rockwool':{'domain':'rockwool.com','strategy':'official_product_page'},
}

def manufacturer_search_rule(manufacturer):
 key=clean(manufacturer).lower()
 for name,rule in MANUFACTURER_SEARCH_RULES.items():
  if name in key:return rule
 return None

def previous_verified_product_documents(con,manufacturer,product,article,project):
 # Reuse only exact manufacturer/product/article matches from other projects.
 # This is a hint, never an automatic approval or a copied PDF.
 if not clean(article):return []
 rows=con.execute('SELECT c.manufacturer,c.product,c.article_no,c.project,d.doc_type,d.title,d.source_url FROM components c JOIN documents d ON d.component_id=c.id WHERE c.project!=? AND d.verified=1 AND d.source_url!="" ORDER BY c.project,d.doc_type',(project,)).fetchall()
 expected=product_key(manufacturer,product)
 result=[];seen=set()
 for m,p,a,proj,kind,title,url in rows:
  if product_key(m,p)!=expected or clean(a).upper()!=clean(article).upper():continue
  if url in seen:continue
  seen.add(url);result.append((proj,kind,title,url))
 return result[:12]

def search_product_for_component(manufacturer,product,model):
 ml=clean(manufacturer).lower()
 if 'trox' not in ml:return product
 import re
 values=[clean(product).upper(),clean(model).upper()]
 hits=set()
 for val in values:
  normalized=re.sub(r'[.‐‑‒–—−_\s]+','-',val)
  for code in ('FKRS-EU','FK2-EU','TVE'):
   if re.search(r'(?<![A-Z0-9])'+re.escape(code)+r'(?![A-Z0-9])',normalized):
    hits.add(code)
 if len(hits)==1:return next(iter(hits))
 return product

def resolve_product_page(manufacturer, product):
 key=product_key(manufacturer,product)
 if key not in PRODUCTS:
  raise ValueError('Für dieses Produkt ist die automatische Herstellersuche in v0.4.4 noch nicht freigeschaltet.')
 rule=manufacturer_search_rule(manufacturer)
 if not rule:raise ValueError('Für diesen Hersteller ist noch kein geprüftes Suchmodul hinterlegt.')
 allowed=rule['domain']
 errors=[]
 for candidate in PRODUCTS[key]:
  try:
   host=urlparse(candidate).netloc.lower()
   if allowed not in host:
    continue
   r=requests.get(candidate,headers={'User-Agent':'Mozilla/5.0 (TGA Product Finder v0.4.4)'},timeout=25,allow_redirects=True)
   final_host=urlparse(r.url).netloc.lower()
   if allowed not in final_host:
    errors.append(f'{candidate}: Weiterleitung außerhalb der Herstellerdomain')
    continue
   if r.status_code==200:
    return r.url, r
   errors.append(f'{candidate}: HTTP {r.status_code}')
  except requests.RequestException as e:
   errors.append(f'{candidate}: {e}')
 raise ValueError('Keine gültige offizielle Produktseite erreichbar. Geprüft: ' + ' | '.join(errors))

def rockwool_context(a):
 # Kontext bewusst klein halten: höchstens der direkte Link-Container.
 # Große Elterncontainer enthalten bei ROCKWOOL oft mehrere Dokumentbereiche
 # und sogar Footer/Navigation und würden Kategorien falsch "vererben".
 parts=[]
 for node in [a, a.parent]:
  if node is not None and hasattr(node,'get_text'):
   t=clean(node.get_text(' ',strip=True))
   if t and len(t) <= 600 and t not in parts: parts.append(t)
 return ' '.join(parts)[:800]

def rockwool_noise(title,url):
 b=(title+' '+url).lower()
 terms=['allgemeine einkaufsbedingungen','aeb','allgemeine geschäftsbedingungen','agb',
        'cookie-erklärung','cookie erklaerung','datenschutz','impressum','kontakt',
        'nutzungsbedingungen','nutzungsrechte marke','zum haupt-inhalt springen',
        'zurück zu produkte','zurueck zu produkte','rockcommerce','webshop',
        'tools und rechner','jetzt ausprobieren']
 return any(x in b for x in terms)

def universal_product_search_patterns(manufacturer,product,article=""):
 """Create type-aware queries; do not mistake a model name for an article number."""
 import re
 m=str(manufacturer or "").strip(); p=str(product or "").strip(); a=str(article or "").strip()
 def article_number(value):
  v=value.strip()
  return bool(v and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/-]{3,}",v) and any(c.isdigit() for c in v))
 # The import field named article can actually contain a model designation.
 number=a if article_number(a) else ""
 model="" if number else a
 if not model and p: model=p
 identity=" ".join(x for x in (m,p,model if model.casefold()!=p.casefold() else "",number) if x)
 raw=[]
 if number: raw.append(("Hersteller + Produkt + Artikelnummer",identity))
 if number: raw.append(("Hersteller + Artikelnummer"," ".join(x for x in (m,number) if x)))
 if model: raw.append(("Hersteller + Modell"," ".join(x for x in (m,model) if x)))
 if p and model and p.casefold()!=model.casefold(): raw.append(("Hersteller + Produkt + Modell"," ".join((m,p,model))))
 if p: raw.append(("Hersteller + Produkt"," ".join(x for x in (m,p) if x)))
 for kind,term in (("Datenblatt","Datenblatt PDF"),("Montageanleitung","Montageanleitung PDF"),("Leistungserklärung","DoP PDF"),("Zulassung","Zulassung PDF"),("EPD","EPD PDF")):
  raw.append((kind," ".join(x for x in (identity,term) if x)))
 seen=set(); result=[]
 for label,query in raw:
  key=query.casefold()
  if key and key not in seen:
   seen.add(key);result.append({"Suchmuster":label,"Suchbegriff":query})
 return result

def scoped_official_document_search(manufacturer,product,model):
 """Follow only HTTPS product-related links on a verified official KERMI page."""
 import requests,re
 from bs4 import BeautifulSoup
 from urllib.parse import urlparse,urljoin
 if "kermi" not in str(manufacturer).casefold(): return [],["Erweiterte Herstellersuche: Für diesen Hersteller noch nicht konfiguriert"]
 root="https://www.kermi.com/de/de/produkte/bad-und-wohnheizkoerper/basic-50/"
 session=requests.Session();session.headers.update({"User-Agent":"Mozilla/5.0"})
 found=[];notes=[];seen=set();pages=[root]
 tokens=[x for x in re.split(r"[^a-z0-9]+",(str(product)+" "+str(model)).lower()) if len(x)>3]
 try:
  response=session.get(root,timeout=15);response.raise_for_status()
  soup=BeautifulSoup(response.text,"html.parser")
  for anchor in soup.select("a[href]"):
   url=urljoin(response.url,anchor.get("href",""));u=urlparse(url)
   if u.scheme!="https" or not u.hostname or not (u.hostname=="kermi.com" or u.hostname.endswith(".kermi.com")):continue
   label=(anchor.get_text(" ",strip=True)+" "+url).lower()
   if tokens and not any(t in label for t in tokens):continue
   if u.path.lower().endswith(".pdf"):
    if url not in seen:
     seen.add(url);found.append({"Kategorie":"Sonstiges","Titel":anchor.get_text(" ",strip=True) or u.path.rsplit("/",1)[-1],"Treffer %":55,"URL":url,"Quellseite":root,"Relevant":False,"Priorität":"Offizielle Quelle; Produktvariante prüfen"})
   elif len(pages)<5 and url not in pages and url.rstrip("/")!=root.rstrip("/"):pages.append(url)
  notes.append("KERMI: "+str(len(pages))+" thematisch passende offizielle Seiten identifiziert")
  for page in pages[1:]:
   try:
    res=session.get(page,timeout=12,allow_redirects=False)
    if res.status_code!=200 or "text/html" not in res.headers.get("content-type","").lower():continue
    soup2=BeautifulSoup(res.text,"html.parser")
    for anchor in soup2.select("a[href]"):
     url=urljoin(page,anchor.get("href",""));u=urlparse(url)
     if u.scheme!="https" or not u.hostname or not (u.hostname=="kermi.com" or u.hostname.endswith(".kermi.com")) or not u.path.lower().endswith(".pdf") or url in seen:continue
     label=(anchor.get_text(" ",strip=True)+" "+url).lower()
     if tokens and not any(t in label for t in tokens):continue
     seen.add(url);found.append({"Kategorie":"Sonstiges","Titel":anchor.get_text(" ",strip=True) or u.path.rsplit("/",1)[-1],"Treffer %":55,"URL":url,"Quellseite":page,"Relevant":False,"Priorität":"Offizielle Quelle; Produktvariante prüfen"})
   except requests.RequestException as exc:notes.append("Unterseite nicht erreichbar: "+str(exc)[:90])
 except requests.RequestException as exc:notes.append("KERMI-Herstellerseite nicht erreichbar: "+str(exc)[:110])
 notes.append("KERMI: "+str(len(found))+" zusätzliche PDF-Links (nicht fachlich freigegeben)")
 return found,notes

def search_document_focused_web(manufacturer,product,model,official_url=""):
 """Discover manufacturer product pages via robots, XML/GZ sitemaps and limited navigation."""
 import requests,re,gzip,xml.etree.ElementTree as ET
 from bs4 import BeautifulSoup
 from urllib.parse import urlparse,urljoin,unquote
 from collections import deque
 manufacturer=str(manufacturer).strip();product=str(product).strip();model=str(model).strip()
 basic_e="kermi" in manufacturer.casefold() and bool(re.search(r"(?<![a-z0-9])basic[ –—‐−-]*e(?![a-z0-9])",(product+" "+model).casefold()))
 notes=[]
 if basic_e:notes.append("Produktabgleich: Basic-E und Basic 50 bleiben getrennt")
 parsed=urlparse(str(official_url or ""))
 if "kermi" in manufacturer.casefold():domain="www.kermi.com"
 elif parsed.scheme=="https" and parsed.hostname and re.fullmatch(r"[a-z0-9.-]+",parsed.hostname) and not parsed.hostname.endswith((".local",".internal")):domain=parsed.hostname
 else:return [],notes+["Produktidentifikation: Keine verifizierbare Herstellerdomain vorhanden"]
 base="https://"+domain
 session=requests.Session();session.headers.update({"User-Agent":"Mozilla/5.0 (compatible; TGAProductFinder/2.0)"})
 attempts=[];errors=[];xml_count=0;discovered=0
 def fetch(url):
  p=urlparse(url)
  if p.scheme!="https" or p.hostname!=domain:return None
  try:
   r=session.get(url,timeout=9,allow_redirects=False,stream=True)
   attempts.append(str(r.status_code)+" "+p.path[:90])
   if r.status_code!=200:return None
   size=0;chunks=[]
   for chunk in r.iter_content(65536):
    size+=len(chunk)
    if size>2500000:errors.append("Antwort zu groß: "+p.path[:70]);return None
    chunks.append(chunk)
   r._content=b"".join(chunks)
   return r
  except requests.RequestException as exc:
   errors.append(type(exc).__name__+" "+p.path[:70]);return None
  finally:
   try:r.close()
   except UnboundLocalError:pass
 # Document-based evidence: bounded verified PDF, never auto-approve a variant.
 document_sources=[]
 if basic_e:
  document_sources=["https://www.heizungsdiscount24.de/pdf/Kermi-Badheizkoerper-Basic-E-AK3-Montageanleitung.pdf"]
 if parsed.scheme=="https" and parsed.path.lower().endswith(".pdf") and parsed.hostname==domain:document_sources.insert(0,str(official_url))
 doc_checked=0;doc_evidence=[];doc_errors=[]
 for pdf_url in document_sources[:2]:
  try:
   rr=requests.get(pdf_url,timeout=12,stream=True,headers={"User-Agent":"Mozilla/5.0"})
   if rr.status_code!=200:doc_errors.append("HTTP "+str(rr.status_code));rr.close();continue
   buf=bytearray()
   for chunk in rr.iter_content(65536):
    buf.extend(chunk)
    if len(buf)>4500000:break
   rr.close()
   if len(buf)>4500000 or not bytes(buf[:5])==b"%PDF-":doc_errors.append("Keine kleine gültige PDF");continue
   doc_checked+=1;pdf_text=""
   try:
    from pypdf import PdfReader
    from io import BytesIO
   except ImportError:
    try:
     import subprocess,sys,importlib
     install=subprocess.run([sys.executable,"-m","pip","install","--disable-pip-version-check","--quiet","pypdf>=5,<7"],capture_output=True,text=True,timeout=60,check=False)
     if install.returncode!=0:raise RuntimeError("Installation fehlgeschlagen: "+install.stderr[-160:])
     importlib.invalidate_caches()
     from pypdf import PdfReader
     from io import BytesIO
     notes.append("PDF-Bibliothek: pypdf automatisch eingerichtet")
    except (ImportError,RuntimeError,subprocess.TimeoutExpired) as exc:
     doc_errors.append("PDF-Bibliothek nicht verfügbar: "+str(exc)[:180])
     PdfReader=None
   if PdfReader is not None:
    try:
     pdf=PdfReader(BytesIO(buf));page_texts=[(page.extract_text() or "") for page in pdf.pages[:80]];pdf_text=" ".join(page_texts)
     total_pages=len(pdf.pages);empty_pages=sum(not t.strip() for t in page_texts)
     notes.append("PDF-Textausbeute: "+str(total_pages)+" Seiten insgesamt, "+str(len(page_texts))+" analysiert, "+str(len(pdf_text))+" Zeichen, "+str(empty_pages)+" leere Textseiten")
     if total_pages>80:notes.append("PDF-Analyse begrenzt: erste 80 Seiten")
     if not pdf_text.strip():doc_errors.append("PDF enthält keinen extrahierbaren Text (ggf. Scan)")
    except Exception as exc:doc_errors.append("PDF-Textfehler: "+type(exc).__name__)
   if pdf_text:
    matches=sorted(set(re.findall(r"basic[\s\u00ad\-\u2010-\u2015]*e(?![a-z0-9])(?:[\s\-]*[a-z0-9]{1,10})?",pdf_text,re.I)))[:8]
    # Manufacturer-neutral candidate discovery from text; evidence only, not an assignment.
    import unicodedata
    def normalize(value):
     value=unicodedata.normalize("NFKC",str(value)).casefold()
     return re.sub(r"[^a-z0-9]+","",value)
    expected=[x for x in (product,model) if len(normalize(x))>=4]
    manufacturer_key=normalize(manufacturer)
    manufacturer_pages=[i+1 for i,t in enumerate(page_texts) if manufacturer_key and manufacturer_key in normalize(t)]
    notes.append("PDF-Herstellerabgleich: "+str(len(manufacturer_pages))+" Textseiten mit Herstellerhinweis")
    if expected:
     for term in expected[:2]:
      pages=[i+1 for i,t in enumerate(page_texts) if normalize(term) in normalize(t)]
      notes.append("PDF-Abgleich "+repr(term[:35])+": "+str(len(pages))+" Seiten mit exakter normalisierter Zeichenfolge"+(", Seiten "+", ".join(map(str,pages[:5])) if pages else ""))
    candidate_hits=[];candidate_seen=set()
    for page_no,page_text in enumerate(page_texts,1):
     for raw_line in page_text.splitlines()[:500]:
      line=" ".join(raw_line.split())[:160]
      if not 4<=len(line)<=120:continue
      if not re.search(r"(?i)(?:basic|typ\s*[:/]|modell\s*[:/]|model\s*[:/]|art(?:ikel)?\.?\s*[- ]?nr\.?|\b[A-Z]{2,5}[- /]?\d{2,6}\b)",line):continue
      if re.search(r"(?i)https?://|www\.|copyright|telefon|fax|seite\s+\d",line):continue
      key=normalize(line)
      if key in candidate_seen:continue
      candidate_seen.add(key);candidate_hits.append((page_no,line))
      if len(candidate_hits)>=12:break
     if len(candidate_hits)>=12:break
    notes.append("PDF-Produktkandidaten: "+str(len(candidate_hits))+" unterschiedliche Textzeilen (ungeprüft)")
    for page_no,line in candidate_hits[:8]:notes.append("PDF-Kandidat Seite "+str(page_no)+": "+line[:110])
    # Evidence scoring is deliberately conservative and does not grant approval.
    def document_evidence_score(text_pages,make,designation,variant):
     import unicodedata
     def tokens(s):
      s=unicodedata.normalize("NFKC",str(s)).casefold()
      return [v for v in re.split(r"[^a-z0-9]+",s) if len(v)>=2]
     flat=" ".join(text_pages)
     flat_tokens=tokens(flat)
     doc_set=set(flat_tokens)
     make_tokens=tokens(make);name_tokens=tokens(designation);variant_tokens=tokens(variant)
     make_hits=[v for v in make_tokens if v in doc_set]
     name_hits=[v for v in name_tokens if v in doc_set]
     variant_hits=[v for v in variant_tokens if v in doc_set]
     normalized=re.sub(r"[^a-z0-9]+","",flat.casefold())
     exact_name=bool(name_tokens) and "".join(name_tokens) in normalized
     exact_variant=bool(variant_tokens) and "".join(variant_tokens) in normalized
     conflict=bool(basic_e and re.search(r"(?i)basic\s*[- ]?50",flat) and not re.search(r"(?i)basic\s*[- ]?e\b",flat))
     score=min(95,25*bool(make_hits)+20*bool(name_hits)+20*bool(variant_hits)+15*exact_name+15*exact_variant)
     if conflict:score=min(score,20)
     return score,make_hits,name_hits,variant_hits,conflict
    score,make_hits,name_hits,variant_hits,conflict=document_evidence_score(page_texts,manufacturer,product,model)
    notes.append("PDF-Produktabgleich: "+str(score)+" % Indizienwert (keine Freigabe); Hersteller "+str(len(make_hits))+", Produkt "+str(len(name_hits))+", Modell "+str(len(variant_hits))+" passende Tokens")
    if conflict:notes.append("PDF-Konflikt: Basic 50 ohne Basic-E-Nachweis; keine Zuordnung")
    if score<60:notes.append("PDF-Zuordnung: ungeprüft; Produktidentität nicht ausreichend belegt")
    else:notes.append("PDF-Zuordnung: Kandidat zur manuellen Prüfung; keine automatische Freigabe")
    # Extract exact technical type identifiers; do not assume a family relationship.
    type_pattern=re.compile(r"\b(?:[A-Z][A-Z0-9]{1,5}\d{1,5}|E0E\d{2,5})\s*[-/]?\s*AK\s*\d{1,3}\b",re.I)
    types_found={}
    for page_no,content in enumerate(page_texts,1):
     for match in type_pattern.finditer(content):
      typ=" ".join(match.group(0).upper().split())
      if typ not in types_found:types_found[typ]=[]
      if page_no not in types_found[typ]:types_found[typ].append(page_no)
    notes.append("PDF-Typenextraktion: "+str(len(types_found))+" unterschiedliche technische Typen (ungeprüft)")
    for typ,pages in list(types_found.items())[:12]:notes.append("PDF-Technischer Typ: "+typ+" | Seite "+", ".join(map(str,pages[:8])))
    model_normalized=re.sub(r"[^A-Z0-9]","",model.upper())
    direct=[typ for typ in types_found if re.sub(r"[^A-Z0-9]","",typ)==model_normalized]
    if direct:notes.append("PDF-Typenabgleich: Exakter technischer Typ stimmt überein; Hersteller und Ausführung weiter prüfen")
    elif types_found:notes.append("PDF-Typenabgleich: Technische Typen gefunden, aber keine belegte Zuordnung zur Produktfamilie "+model[:50])
    if basic_e and types_found:notes.append("KERMI-Prüfstatus: ERE10/E0E10 dürfen ohne offiziellen Typen-Familiennachweis nicht Basic-E zugeordnet werden")
    if matches:doc_evidence.extend(matches)
    if not matches and len(pdf_text)>0:notes.append("PDF-Produktsuche: Text vorhanden, aber keine eindeutige Basic-E-Bezeichnung")
    if matches:
     for hit in matches[:5]:
      page_numbers=[str(i+1) for i,t in enumerate(page_texts) if re.search(re.escape(hit),t,re.I)]
      if page_numbers:notes.append("PDF-Fundstelle: "+hit[:45]+" auf Seite "+", ".join(page_numbers[:5]))
  except requests.RequestException as exc:doc_errors.append(type(exc).__name__)
 notes.append("Dokumentenanalyse: "+str(doc_checked)+" PDF geprüft, "+str(len(doc_evidence))+" Basic-E-Textmerkmale; keine automatische Variantenfreigabe")
 if doc_evidence:notes.append("PDF-Produktmerkmale (ungeprüft): "+", ".join(doc_evidence))
 if doc_errors:notes.append("PDF-Diagnose: "+"; ".join(doc_errors[:3]))
 candidates=[];seen_urls=set()
 def add(url):
  p=urlparse(url)
  if p.scheme=="https" and p.hostname==domain and url not in seen_urls:
   seen_urls.add(url);candidates.append(url)
 sitemap_queue=deque([base+"/de/de/sitemap.xml",base+"/sitemap.xml",base+"/sitemap_index.xml"])
 robots=fetch(base+"/robots.txt")
 if robots is not None:
  for line in robots.text.splitlines():
   if line.lower().lstrip().startswith("sitemap:"):
    u=line.split(":",1)[1].strip()
    if urlparse(u).scheme=="https" and urlparse(u).hostname==domain:sitemap_queue.append(u)
 visited_xml=set()
 while sitemap_queue and xml_count<12:
  url=sitemap_queue.popleft()
  if url in visited_xml:continue
  visited_xml.add(url);r=fetch(url)
  if r is None:continue
  payload=r.content
  if urlparse(url).path.endswith(".gz") or payload[:2]==b"\x1f\x8b":
   try:payload=gzip.decompress(payload)
   except (OSError,EOFError):errors.append("GZIP ungültig: "+urlparse(url).path[:70]);continue
  if len(payload)>12000000:errors.append("XML zu groß: "+urlparse(url).path[:70]);continue
  try:tree=ET.fromstring(payload)
  except ET.ParseError:errors.append("XML ungültig: "+urlparse(url).path[:70]);continue
  xml_count+=1
  for node in tree.iter():
   if node.tag.rsplit("}",1)[-1]!="loc" or not node.text:continue
   link=node.text.strip();p=urlparse(link)
   if p.scheme!="https" or p.hostname!=domain:continue
   if p.path.lower().endswith((".xml",".xml.gz")):
    if len(sitemap_queue)<80 and ("/de/de/" in p.path or "/de/" in p.path):sitemap_queue.appendleft(link)
   elif "/de/de/" in p.path or "/de/" in p.path:add(link);discovered+=1
 nav=0
 if not candidates:
  for root in ([str(official_url)] if parsed.scheme=="https" and parsed.hostname==domain else [])+[base+"/de/de/"]:
   r=fetch(root)
   if r is None or "html" not in r.headers.get("content-type","").lower():continue
   nav+=1;soup=BeautifulSoup(r.text,"html.parser")
   for a in soup.select("a[href]")[:1500]:
    target=urljoin(root,a.get("href",""));p=urlparse(target)
    if p.hostname==domain and p.scheme=="https":add(target)
 pattern=re.compile(r"basic[-_/ ]?e(?![a-z0-9])",re.I)
 terms=[t for t in re.split(r"[^a-z0-9]+",model.casefold()) if len(t)>2]
 ranked=[u for u in candidates if (pattern.search(unquote(urlparse(u).path)) if basic_e else bool(terms and all(t in unquote(urlparse(u).path).casefold() for t in terms)))]
 notes.append("Sitemap-Diagnose: "+str(xml_count)+" XML-Sitemaps, "+str(discovered)+" deutsche Sitemap-URLs, "+str(nav)+" Navigations-Startseiten, "+str(len(ranked))+" Modell-URL-Kandidaten")
 notes.append("Sitemap-Abrufe: "+"; ".join(attempts[:12]))
 if errors:notes.append("Sitemap-Fehler: "+"; ".join(errors[:5]))
 content_checked=0;content_matches=[]
 if basic_e:
  keywords=("heizkoerper","heizkörper","badheiz","badheizkoerper","radiator","bad-und-design","basic","elektro","electric","handtuch")
  pool=[u for u in candidates if any(k in unquote(urlparse(u).path).casefold() for k in keywords)]
  pool=sorted(pool,key=lambda u:(0 if "basic" in u.casefold() else 1,0 if "bad" in u.casefold() or "heiz" in u.casefold() else 1,len(u)))
  for url in pool[:32]:
   if url in ranked:continue
   r=fetch(url)
   if r is None or "html" not in r.headers.get("content-type","").lower():continue
   content_checked+=1;soup=BeautifulSoup(r.text,"html.parser")
   title=soup.title.get_text(" ",strip=True) if soup.title else ""
   headings=" ".join(h.get_text(" ",strip=True) for h in soup.select("h1,h2,h3")[:12])
   if re.search(r"basic\s*[- ]?e(?![a-z0-9])",title+" "+headings,re.I):content_matches.append((url,soup))
  notes.append("Inhaltssuche: "+str(len(pool))+" relevante URL-Kandidaten, "+str(content_checked)+" Seiten geprüft, "+str(len(content_matches))+" Basic-E-Titel-/Überschriftentreffer")
 validated=[]
 validated.extend(content_matches)
 for url in ranked[:8]:
  r=fetch(url)
  if r is None or "html" not in r.headers.get("content-type","").lower():continue
  soup=BeautifulSoup(r.text,"html.parser")
  title=soup.title.get_text(" ",strip=True) if soup.title else ""
  heading=" ".join(h.get_text(" ",strip=True) for h in soup.select("h1,h2")[:5])
  evidence=title+" "+heading
  if basic_e and not re.search(r"basic\s*[- ]?e(?![a-z0-9])",evidence,re.I):continue
  if not basic_e and not all(t in evidence.casefold() for t in terms):continue
  if url not in [x[0] for x in validated]:validated.append((url,soup))
 found=[];seen=set()
 for page,soup in validated:
  for a in soup.select("a[href]"):
   target=urljoin(page,a.get("href",""));p=urlparse(target)
   if p.scheme!="https" or p.hostname!=domain or not p.path.lower().endswith(".pdf"):continue
   label=a.get_text(" ",strip=True);context=(label+" "+unquote(p.path)).casefold()
   if basic_e and not pattern.search(context):continue
   if target in seen:continue
   seen.add(target)
   found.append({"Kategorie":"Sonstiges","Titel":label or p.path.rsplit("/",1)[-1],"Treffer %":50,"URL":target,"Quellseite":page,"Relevant":False,"Priorität":"Hersteller-PDF-Kandidat; Variante prüfen"})
 notes.append("Produktidentifikation: "+str(len(validated))+" passende Produktseiten, "+str(len(found))+" ungeprüfte PDF-Kandidaten")
 if not validated:notes.append("Keine bestätigte Hersteller-Produktseite; vorhandene Drittquellen bleiben unverändert")
 return found,notes
def multistage_document_candidates(manufacturer,product,model,official_url=""):
 """One action: official product discovery, verified page candidates, and KERMI fallback."""
 stages=[]; hits=[]; source=""
 def merge(items):
  seen={str(x.get("URL","")).strip().lower() for x in hits}
  for item in items:
   key=str(item.get("URL","")).strip().lower()
   if key and key not in seen: hits.append(item);seen.add(key)
 try:
  source,items=discover_official_product_docs(manufacturer,product,model)
  merge(items);stages.append("Offizielle Produktseite automatisch geprüft")
 except Exception as exc:
  stages.append("Herstellerermittlung: "+str(exc)[:140])
 if official_url and official_url.startswith("https://"):
  try:
   page,items=universal_docs_from_official_page(manufacturer,product,model,official_url)
   if not source:source=page
   merge(items);stages.append("Angegebene Herstellerseite geprüft")
  except Exception as exc:
   stages.append("Herstellerseite: "+str(exc)[:140])
 if "kermi" in str(manufacturer).casefold() and "basic" in (str(product)+" "+str(model)).casefold():
  try:
   merge(kermi_basic_official_documents());stages.append("KERMI-Produkt- und geprüfte Drittquelle geprüft")
  except Exception as exc:
   stages.append("KERMI-Quellen: "+str(exc)[:140])
 try:
  extra,notes=scoped_official_document_search(manufacturer,product,model)
  merge(extra);stages.extend(notes)
 except Exception as exc:stages.append("Erweiterte Herstellersuche: "+str(exc)[:110])
 try:
  extra,notes=search_document_focused_web(manufacturer,product,model,official_url)
  merge(extra);stages.extend(notes)
 except Exception as exc:stages.append("Dokumentenorientierte Websuche: "+str(exc)[:110])
 return source,hits,stages

def document_source_policy(url, original_url=None):
 """Return source class and whether this exact PDF URL may be saved."""
 from urllib.parse import urlparse
 u=urlparse(url)
 if u.scheme != "https" or not u.hostname or u.username or u.password: return ("Unbekannte Quelle",False)
 host=u.hostname.lower()
 official=(host in ("heliosventilatoren.de","assets.danfoss.com") or host.endswith(".heliosventilatoren.de"))
 if official: return ("1 – Offizielle Herstellerquelle",True)
 kermi="https://www.heizungsdiscount24.de/pdf/Kermi-Badheizkoerper-Basic-E-AK3-Montageanleitung.pdf"
 if url==kermi and (original_url is None or original_url==kermi): return ("2 – Geprüfte Drittquelle (KERMI Basic-E AK3)",True)
 return ("3 – Unbekannte Quelle",False)

def save_universal_pdf_candidate(con,component_id,project,manufacturer,product,doc):
 """Offline-save a reviewed candidate without technical approval."""
 from urllib.parse import urlparse
 import requests,os,hashlib
 url=doc['URL']
 u=urlparse(url)
 if not document_source_policy(url)[1]:
  raise ValueError('Nur freigegebene offizielle Hersteller-PDF-Hosts zulässig.')
 response=requests.get(url,timeout=45,allow_redirects=True,headers={'User-Agent':'Mozilla/5.0'},stream=True)
 response.raise_for_status()
 final=urlparse(response.url)
 if not document_source_policy(response.url,url)[1]:
  response.close();raise ValueError('PDF-Weiterleitung außerhalb der Herstellerdomain.')
 limit=25*1024*1024
 data=bytearray()
 try:
  for chunk in response.iter_content(chunk_size=65536):
   if chunk:
    data.extend(chunk)
    if len(data)>limit:raise ValueError('PDF größer als 25 MB.')
 finally:response.close()
 if not bytes(data[:5])==b'%PDF-':raise ValueError('Der Link liefert keine echte PDF-Datei.')
 # Content-based duplicate detection within the same component.
 digest=hashlib.sha256(data).hexdigest()
 for _row in con.execute("SELECT local_path FROM documents WHERE component_id=? AND local_path IS NOT NULL",(component_id,)).fetchall():
  _existing_path=_row[0]
  if _existing_path and os.path.isfile(_existing_path):
   try:
    with open(_existing_path,"rb") as _file:
     _existing_hash=hashlib.file_digest(_file,"sha256").hexdigest()
    if _existing_hash==digest:
     return _existing_path,len(data)
   except OSError:
    pass
 folder=os.path.join(DOWNLOAD_ROOT,safe(project),safe(manufacturer),safe(product))
 os.makedirs(folder,exist_ok=True)
 basename=safe(os.path.basename(final.path).removesuffix('.pdf')) or 'Dokument'
 filename=basename+'_'+hashlib.sha256(url.encode()).hexdigest()[:10]+'.pdf'
 path=os.path.join(folder,filename)
 with open(path,'wb') as stream:stream.write(data)
 existing=con.execute('SELECT id FROM documents WHERE component_id=? AND source_url=?',(component_id,url)).fetchone()
 if existing:
  con.execute("UPDATE documents SET doc_type=?,title=?,verified=1,confidence=?,source_page=?,local_path=?,download_status=?,priority=?,project_confirmed=0,project_decision='' WHERE id=?",(doc['Kategorie'],doc['Titel'],doc['Treffer %'],doc['Quellseite'],path,'Offline · PDF geprüft','Anwendungsfall prüfen',existing[0]))
 else:
  con.execute("INSERT INTO documents(component_id,doc_type,title,source_url,verified,confidence,source_page,local_path,download_status,priority,project_confirmed,project_decision,project_decision_note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(component_id,doc['Kategorie'],doc['Titel'],url,1,doc['Treffer %'],doc['Quellseite'],path,'Offline · PDF geprüft','Anwendungsfall prüfen',0,'',''))
 con.commit()
 return path,len(data)

def helios_search_pdf_candidates(model='SB 125 A'):
 """HELIOS SB 125 A: official product page and known official document paths."""
 import requests,re
 from bs4 import BeautifulSoup
 from urllib.parse import urljoin,urlparse,unquote
 if re.sub(r'[^a-z0-9]','',model.lower())!='sb125a':
  raise ValueError('Nur HELIOS SB 125 A unterstützt.')
 base='https://select.heliosventilatoren.de/de-de/get/product?language_id=de&ref_no=09506'
 session=requests.Session()
 session.headers.update({'User-Agent':'Mozilla/5.0','Accept-Language':'de-DE,de;q=0.9'})
 known=[
  ('Montage- und Betriebsvorschrift SB AC (08/2025)','https://global.heliosventilatoren.de/mediadata/product/mbv/SB_AC_95235-002_0825.pdf'),
  ('Montage- und Betriebsvorschrift SB AC (11/2023)','https://global.heliosventilatoren.de/mediadata/product/mbv/SB_AC_95235-002_1123.pdf'),
  ('Schaltplan ss_508','https://global.heliosventilatoren.de/mediadata/product/schaltplan/ss_508.pdf'),
  ('Maßzeichnung mb1949001','https://global.heliosventilatoren.de/mediadata/product/massblatt/mb1949001.pdf')]
 candidates=list(known);warnings=[];found={}
 try:
  page=session.get(base,timeout=15)
  page.raise_for_status()
  soup=BeautifulSoup(page.text,'html.parser')
  for a in soup.select('a[href]'):
   url=urljoin(page.url,a.get('href',''))
   title=a.get_text(' ',strip=True) or a.get('title','') or urlparse(url).path.rsplit('/',1)[-1]
   if '.pdf' in urlparse(url).path.lower():candidates.append((title,url))
 except requests.RequestException as exc:
  warnings.append('HELIOS-Produktseite nicht abrufbar: '+str(exc)[:120])
 for title,url in candidates[:100]:
  parsed=urlparse(url)
  host=(parsed.hostname or '').lower()
  if parsed.scheme!='https' or not (host=='heliosventilatoren.de' or host.endswith('.heliosventilatoren.de')):continue
  try:
   response=session.get(url,timeout=18,stream=True,allow_redirects=True)
   response.raise_for_status()
   final=response.url
   final_host=(urlparse(final).hostname or '').lower()
   if not (final_host=='heliosventilatoren.de' or final_host.endswith('.heliosventilatoren.de')):continue
   first=next(response.iter_content(chunk_size=4096),b'')
   if not first.startswith(b'%PDF-'):continue
   if final in found:continue
   found[final]={'Kategorie':classify(title,final,'generic'),'Titel':title,
     'Treffer %':75,'URL':final,'Quellseite':base,
     'Relevant':False,'Priorität':'Ausführung und Dokumentstand prüfen'}
  except requests.RequestException:continue
 if not found:warnings.append('Kein offizieller PDF-Endpunkt lieferte verifizierbare PDF-Daten.')
 ordered=list(found.values())
 if any('SB_AC_95235-002_0825.pdf' in item.get('URL','') for item in ordered):
  ordered=[item for item in ordered if 'SB_AC_95235-002_1123.pdf' not in item.get('URL','')]
  for item in ordered:
   if 'SB_AC_95235-002_0825.pdf' in item.get('URL',''):
    item['Treffer %']=80
    item['Priorität']='Neueste verfügbare Ausgabe; Produktzuordnung prüfen'
 return ordered[:30],warnings

def kermi_basic_official_documents():
 import requests
 from bs4 import BeautifulSoup
 from urllib.parse import urljoin,urlparse
 page_url='https://www.kermi.com/de/de/produkte/bad-und-wohnheizkoerper/basic-50/'
 session=requests.Session()
 session.headers.update({'User-Agent':'Mozilla/5.0 (compatible; TGA-Product-Finder/2.0)','Accept-Language':'de-DE,de;q=0.9'})
 response=session.get(page_url,timeout=18)
 response.raise_for_status()
 soup=BeautifulSoup(response.text,'html.parser')
 hits=[];seen=set()
 for a in soup.select('a[href]'):
  href=a.get('href','');label=a.get_text(' ',strip=True)
  url=urljoin(response.url,href)
  parsed=urlparse(url)
  host=(parsed.hostname or '').lower()
  if not (host=='kermi.com' or host.endswith('.kermi.com')):continue
  if '.pdf' not in parsed.path.lower():continue
  if url in seen:continue
  if not any(x in (label+' '+url).lower() for x in ('basic','montage','anleitung','heizkörper','heizkoerper','bedien','prospekt','datenblatt')):continue
  try:
   pdf=session.get(url,timeout=18,stream=True)
   pdf.raise_for_status()
   first=next(pdf.iter_content(chunk_size=4096),b'')
   if not first.startswith(b'%PDF-'):continue
   seen.add(url)
   hits.append({'Kategorie':'Planung & Montage' if 'montage' in label.lower() or 'anleitung' in label.lower() else 'Produktdatenblatt','Titel':label or parsed.path.rsplit('/',1)[-1],'Treffer %':65,'URL':url,'Quellseite':page_url,'Relevant':False,'Priorität':'KERMI Produktfamilie Basic; genaue Ausführung prüfen'})
  except requests.RequestException:continue
 # Herstellerdokument über eine produktspezifische Händlerseite als Sekundärquelle.
 # Die PDF-Signatur wird vor Anzeige geprüft; keine automatische Freigabe.
 vendor_url='https://www.heizungsdiscount24.de/pdf/Kermi-Badheizkoerper-Basic-E-AK3-Montageanleitung.pdf'
 try:
  res=session.get(vendor_url,timeout=20,stream=True)
  res.raise_for_status()
  first=next(res.iter_content(chunk_size=4096),b'')
  res.close()
  if first.startswith(b'%PDF-') and vendor_url not in seen:
   hits.append({'Kategorie':'Montage & Betrieb – Hauptanleitung','Titel':'KERMI Basic-E – Montageanleitung AK3 (verifizierte PDF; Ausführung prüfen)','Treffer %':75,'URL':vendor_url,'Quellseite':'https://www.heizungsdiscount24.de/pdf/Kermi-Badheizkoerper-Basic-E-AK3-Montageanleitung.pdf','Relevant':False,'Priorität':'Prüfen: Herstellerdokument über Händlerquelle; Modell und Revision vor Freigabe bestätigen'})
 except requests.RequestException:
  pass
 return hits[:30]

def discover_official_product_docs(manufacturer,product,model):
 """Try an official product page without requiring user to paste its address."""
 import re
 from urllib.parse import urlparse,parse_qs,unquote
 import requests
 from bs4 import BeautifulSoup
 m=clean(manufacturer).lower(); wanted=' '.join(str(x or '') for x in (product,model)).lower()
 candidates=[]
 if 'danfoss' in m and 'ecl' in wanted and '310' in wanted:
  source='https://www.danfoss.com/de-de/products/dhs/electronic-controls/electronic-controllers-and-application-keys/ecl-comfort-controllers/'
  url='https://assets.danfoss.com/documents/latest/374251/AI155886473192en-010702.pdf'
  return source,[{'Kategorie':'Produktdatenblatt','Titel':'ECL Comfort 310 – allgemeines Herstellerdatenblatt (Ausführung prüfen)','Treffer %':55,'URL':url,'Quellseite':source,'Relevant':False,'Priorität':'Anwendungsfall prüfen'}]
 if 'helios' in m and re.search(r'sb[\s_-]*125[\s_-]*a(?![a-z0-9])',wanted):
  candidates.extend(['https://www.heliosventilatoren.de/de/produkte/boxventilatoren/silentbox/sb-125-a-09506','https://www.heliosventilatoren.de/at/produkte-at/boxventilatoren/silentbox/sb-125-a-at-09506'])
 domains={'helios':'heliosventilatoren.de','trox':'trox.de','rockwool':'rockwool.com','geberit':'geberit.de','grohe':'grohe.de','danfoss':'danfoss.com','grundfos':'grundfos.com','wilo':'wilo.com','viega':'viega.de','uponor':'uponor.com','kermi':'kermi.com','geberit':'geberit.de','swegon':'swegon.com','systemair':'systemair.com','wolf':'wolf.eu','vaillant':'vaillant.de','bosch':'bosch-homecomfort.com','siemens':'siemens.com','belimo':'belimo.com','schneider':'se.com','hager':'hager.de','jung':'jung.de','gira':'gira.de','geberit':'geberit.de','tece':'tece.com','dallmer':'dallmer.de','aco':'aco.com','puren':'puren.com','hilti':'hilti.de','knauf':'knauf.com'}
 domain=next((v for k,v in domains.items() if k in m),None)
 if domain:
  query='site:'+domain+' '+ ' '.join(str(x or '').strip() for x in (manufacturer,product,model) if str(x or '').strip())
  try:
   r=requests.get('https://www.google.com/search',params={'q':query,'num':8},timeout=12,headers={'User-Agent':'Mozilla/5.0'})
   if r.ok:
    soup=BeautifulSoup(r.text,'html.parser')
    for a in soup.select('a[href]'):
     href=a.get('href','')
     if href.startswith('/url?'):href=parse_qs(urlparse(href).query).get('q',[''])[0]
     href=unquote(href)
     host=(urlparse(href).hostname or '').lower()
     if urlparse(href).scheme=='https' and (host==domain or host.endswith('.'+domain)):
      if href not in candidates:candidates.append(href)
  except requests.RequestException:pass
 errors=[]
 for url in candidates[:12]:
  try:
   page,docs=universal_docs_from_official_page(manufacturer,product,model,url)
   if docs:return page,docs
  except (ValueError,requests.RequestException) as exc:errors.append(str(exc))
 raise ValueError('Keine eindeutig passende offizielle Produktseite mit PDFs gefunden. Bitte Hersteller, Typ und Artikelnummer prüfen oder die offizielle Produktadresse verwenden.')

def universal_docs_from_official_page(manufacturer,product,model,page_url):
 """Product page scoped discovery; PDFs remain candidates, not approved."""
 from urllib.parse import urlparse,urljoin
 from bs4 import BeautifulSoup
 import requests,re,ipaddress,socket
 def safe_url(url,root=None):
  u=urlparse(url)
  if u.scheme!='https' or not u.hostname or u.username or u.password:raise ValueError('Nur gültige HTTPS-Herstellerseiten zulässig.')
  host=u.hostname.lower().rstrip('.')
  if root and not (host==root or host.endswith('.'+root)):raise ValueError('Domain außerhalb der Herstellerseite.')
  if host=='localhost' or host.endswith(('.local','.internal','.localhost')):raise ValueError('Lokale Adressen nicht zulässig.')
  try:
   for item in socket.getaddrinfo(host,443,type=socket.SOCK_STREAM):
    if not ipaddress.ip_address(item[4][0]).is_global:raise ValueError('Nichtöffentliche Adresse.')
  except socket.gaierror:raise ValueError('Herstellerdomain nicht erreichbar.')
  return host
 url=clean(page_url);root=safe_url(url)
 if root.endswith('.heliosventilatoren.de') or root=='heliosventilatoren.de':root='heliosventilatoren.de'
 session=requests.Session();session.headers.update({'User-Agent':'Mozilla/5.0 (compatible; TGA-Product-Finder/1.7.2)'})
 def fetch(url):
  safe_url(url,root)
  for _ in range(5):
   response=session.get(url,timeout=18,allow_redirects=False)
   if response.status_code not in (301,302,303,307,308):break
   url=urljoin(response.url,response.headers.get('Location',''))
   safe_url(url,root)
  response.raise_for_status();safe_url(response.url,root)
  if 'text/html' not in response.headers.get('content-type','text/html').lower():raise ValueError('Keine HTML-Produktseite.')
  return response
 first=fetch(url)
 soup=BeautifulSoup(first.text,'html.parser')
 model_keys=[x for x in re.split(r'[^a-z0-9]+',clean(model).lower()) if len(x)>=3]
 product_keys=[x for x in re.split(r'[^a-z0-9]+',clean(product).lower()) if len(x)>=3 and x not in ('produkt','geraet','gerät','ventilator','helios')]
 keys=list(dict.fromkeys(model_keys+product_keys))
 # The page must clearly identify the requested product; otherwise no inherited trust.
 heading=' '.join(x.get_text(' ',strip=True) for x in soup.select('h1,h2,title'))[:2500].lower()
 page_text=soup.get_text(' ',strip=True).lower()[:16000]
 model_code=' '.join(model_keys)
 product_verified=bool(model_code and (model_code in re.sub(r'[^a-z0-9]+',' ',heading) or model_code in re.sub(r'[^a-z0-9]+',' ',page_text)))
 if not product_verified:raise ValueError('Die eingegebene Seite bestätigt die Modellbezeichnung nicht eindeutig. Bitte konkrete Produktseite statt Startseite verwenden.')
 # Model-specific manufacturer article number can be present in page title or text.
 article_ids=set(re.findall(r'(?<!\d)0\d{4}(?!\d)',heading[:2500]))
 if not article_ids:
  article_ids=set(re.findall(r'(?:artikelnummer|art.-nr.|bestellnummer)\s*[:#]?\s*(0\d{4})',page_text[:6000]))
 queue=[(first.url,first.text,0)];visited=set();seen=set();out=[]
 while queue and len(visited)<8:
  current,html,depth=queue.pop(0)
  if current in visited:continue
  visited.add(current)
  page=BeautifulSoup(html,'html.parser')
  for link in page.find_all('a',href=True):
   href=urljoin(current,link['href'])
   try:safe_url(href,root)
   except ValueError:continue
   title=clean(link.get_text(' ',strip=True))
   blob=(title+' '+href).lower()
   cat=classify(title,href,'generic')
   is_pdf=urlparse(href).path.lower().endswith('.pdf')
   if is_pdf and href not in seen:
    if cat=='Sonstiges' and any(t in title.lower() for t in ('schaltplan','wiring diagram')):cat='Schaltplan'
    if cat=='Sonstiges' and any(t in title.lower() for t in ('maßzeichnung','masszeichnung','dimension')):cat='Maßzeichnung'
    if cat=='Sonstiges' and 'katalog' in title.lower():cat='Katalogseite'
    if cat=='Sonstiges':continue
    # A document on the verified product page is a candidate even if the filename lacks model code.
    # A linked overview page requires a model or article reference in the document link.
    matched=any(k in blob for k in keys) or any(a in blob for a in article_ids)
    if depth==0 or matched:
     seen.add(href)
     out.append({'Kategorie':cat,'Priorität':'Anwendungsfall prüfen','Titel':title or href.rsplit('/',1)[-1],'Treffer %':80 if matched else 55,'URL':href,'Quellseite':current,'Relevant':False,'Resolver':'Produktseite bestätigt – PDF manuell prüfen','Downloadbar':True,'Nachweis URL':''})
   elif depth<1 and len(queue)<12 and not is_pdf and any(t in blob for t in ('download','dokument','datenblatt','anleitung','montage','technical','unterlagen')):
    try:
     sub=fetch(href)
     if sub.url not in visited:queue.append((sub.url,sub.text,depth+1))
    except (requests.RequestException,ValueError):pass
   if len(out)>=50:break
  if len(out)>=50:break
 return first.url,out

def find_docs(manufacturer,product):
 page,r=resolve_product_page(manufacturer,product); key=product_key(manufacturer,product); ml=key[0]; allowed='trox.de' if ml=='trox' else 'rockwool.com'
 soup=BeautifulSoup(r.text,'html.parser'); found=[]; seen=set()
 for a in soup.find_all('a',href=True):
  href=urljoin(page,a['href']); title=clean(a.get_text(' ',strip=True)); host=urlparse(href).netloc.lower()
  if allowed not in host: continue
  if ml=='rockwool' and rockwool_noise(title,href): continue
  context=rockwool_context(a) if ml=='rockwool' else ''
  blob=(title+' '+href+' '+context).lower()
  if not ('.pdf' in blob or 'download' in blob or 'herunterladen' in blob or any(x in blob for x in ['datenblatt','montage','anwendbarkeits','zertifikat','certificate','epd','dop','leistungserklärung','konform','pdf','blauer engel','eurofins'])): continue
  sig=href.split('#')[0].rstrip('/')
  if sig in seen:continue
  seen.add(sig)
  classify_title=(title+' '+context) if ml=='rockwool' else title
  cat=classify(classify_title,href,ml)
  if ml=='rockwool':
   meaningful=cat in ['Produktdatenblatt','Leistungserklärung (DoP)','Planung & Montage','Zulassung / Prüfzeugnis','EPD / DGNB / Umwelt','CE / Konformität','Hygiene']
   # Deutsche Conlit 150 U: ROCKWOOL nennt P-NDS04-417 als Verwendbarkeitsnachweis,
   # nicht den generischen DoP-Download als produktspezifische Leistungserklärung.
   if product_key(manufacturer,product)[1]=='CONLIT U' and cat=='Leistungserklärung (DoP)': meaningful=False
   # Generische Download-Links gelten nur dann als relevant, wenn ihr enger
   # Container tatsächlich eine konkrete Dokumentkategorie erkennen lässt.
   generic=title.lower() in ['herunterladen pdf','download pdf','pdf herunterladen','downloads','herunterladen']
   rel=meaningful and (not generic or cat!='Sonstiges')
  else:
   rel=relevance(product,title,href) and cat!='Sonstiges'
  conf=55+(25 if rel else 0)+(15 if cat!='Sonstiges' else 0)+(5 if allowed in host else 0)
  display_title=title or os.path.basename(urlparse(href).path)
  if ml=='rockwool' and title.lower() in ['herunterladen pdf','download pdf','pdf herunterladen'] and cat!='Sonstiges':
   display_title=f'{cat} – {title}'
  resolver='Direkt / Herstellerseite'; downloadbar=True; nachweis_url=''
  if ml=='rockwool' and 'eurofins' in display_title.lower() and product_key(manufacturer,product)[1] in ['800','CONLIT U']: resolver='Zertifikatsregister → Produkt-PDF'
  if ml=='rockwool' and 'blauer engel' in display_title.lower():
   resolver='Offizielles Umweltzeichen-Register'; downloadbar=False
   nachweis_url=ROCKWOOL_DIRECT_CERTIFICATES.get(product_key(manufacturer,product)[1],ROCKWOOL_DIRECT_CERTIFICATES.get('800',{})).get('blue_angel_registry','')
  if ml=='rockwool' and cat=='Leistungserklärung (DoP)': resolver='DoP-Kennung '+ROCKWOOL_DOP_IDS.get(product_key(manufacturer,product)[1],'')
  found.append({'Kategorie':cat,'Priorität':priority(cat,classify_title,href,ml,product),'Titel':display_title,'Treffer %':min(conf,100),'URL':href,'Quellseite':page,'Relevant':rel,'Resolver':resolver,'Downloadbar':downloadbar,'Nachweis URL':nachweis_url})
 found.sort(key=lambda d:(not d['Relevant'], {'Empfohlen':0,'Anwendungsfall prüfen':1,'Optional / Ausführung prüfen':2,'Optional':3}.get(d['Priorität'],4),-d['Treffer %'],d['Kategorie'],d['Titel']))
 return page,found

def grohe_product_page(article):
 return f'https://www.grohe.de/de_de/-{clean(article)}.html'

def find_grohe_docs(article):
 article=clean(article)
 if article not in GROHE_VARIANTS: raise ValueError('GROHE-Variante ist nicht bestätigt.')
 page=grohe_product_page(article)
 # v0.5.3: Verifizierte, artikelnummernbezogene GROHE-Unterlagen zuerst verwenden.
 # Keine Navigation der Produktseite wird mehr als Dokument interpretiert.
 docs=[]
 for d in GROHE_VERIFIED_DOCS.get(article,[]):
  row=dict(d)
  row.update({'Treffer %':100,'Quellseite':page,'Relevant':True})
  row.setdefault('Downloadbar',True)
  row.setdefault('Nachweis URL','')
  docs.append(row)
 return page,docs

def allowed_download(url,manufacturer):
 host=urlparse(url).netloc.lower(); ml=manufacturer.lower()
 if ml=='trox': return 'trox.de' in host
 if ml=='grohe': return ('grohe.de' in host) or ('grohe.com' in host) or ('grohe.co.za' in host)
 return ('rockwool.com' in host) or ('brandcommunity.rockwool.com' in host)

def is_pdf_response(r):
 data=r.content; ctype=(r.headers.get('content-type') or '').lower()
 return 'application/pdf' in ctype or data[:5]==b'%PDF-' or '.pdf' in r.url.lower()

def fetch_best_pdf_from_page(page_url, manufacturer, phrases, doc=None, max_candidates=30):
 """Findet auf einer offiziellen Herstellerseite den bestpassenden echten PDF-Link."""
 headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'}
 r=requests.get(page_url,headers=headers,timeout=60,allow_redirects=True); r.raise_for_status()
 if not allowed_download(r.url,manufacturer): raise ValueError('Spezialquelle verlässt die Herstellerdomain.')
 soup=BeautifulSoup(r.text,'html.parser'); candidates=[]; seen=set()
 wanted=[x.lower() for x in phrases if x]
 for a in soup.find_all('a',href=True):
  href=urljoin(r.url,a['href']); host=urlparse(href).netloc.lower(); title=clean(a.get_text(' ',strip=True)); blob=(title+' '+href).lower()
  if 'rockwool.com' not in host or href in seen: continue
  seen.add(href)
  if rockwool_noise(title,href): continue
  score=sum(35 for x in wanted if x in blob)
  if '.pdf' in blob: score+=60
  if any(x in blob for x in ['download','herunterladen']): score+=10
  if score: candidates.append((score,href,title))
 candidates.sort(reverse=True)
 for _,href,_ in candidates[:max_candidates]:
  try:
   rr=requests.get(href,headers=headers,timeout=60,allow_redirects=True); rr.raise_for_status()
   if allowed_download(rr.url,manufacturer) and is_pdf_response(rr): return rr
  except requests.RequestException:
   pass
 raise ValueError(f'Keine echte PDF in der ROCKWOOL-Spezialquelle gefunden ({len(candidates)} Kandidat(en)).')

def fetch_pdf_near_exact_title(page_url, manufacturer, exact_title):
 """ROCKWOOL-Dokumentkarten inkl. Asset-/JSON-Metadaten robust auflösen."""
 headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'}
 r=requests.get(page_url,headers=headers,timeout=60,allow_redirects=True); r.raise_for_status()
 if not allowed_download(r.url,manufacturer): raise ValueError('Zertifikatsquelle verlässt die Herstellerdomain.')
 soup=BeautifulSoup(r.text,'html.parser'); target=exact_title.lower(); candidates=[]; seen=set()
 def add(raw,score=50):
  if not raw: return
  raw=str(raw).strip().replace('\\u002F','/').replace('\\/','/').replace('&amp;','&')
  if raw.startswith('//'): raw='https:'+raw
  href=urljoin(r.url,raw)
  host=urlparse(href).netloc.lower(); blob=href.lower()
  if href in seen: return
  if not (('rockwool.com' in host) or ('brandcommunity.rockwool.com' in host)): return
  if any(x in blob for x in ['javascript:','mailto:']): return
  seen.add(href)
  if '.pdf' in blob: score+=150
  if any(x in blob for x in ['asset','download','media']): score+=35
  candidates.append((score,href))
 # 1) Exakte Dokumentkarte + alle Attribute der Karte/Eltern (ROCKWOOL legt URLs teils in data-* ab).
 for node in soup.find_all(string=lambda x: x and target in clean(x).lower()):
  parent=node.parent
  for depth in range(9):
   if parent is None: break
   context=clean(parent.get_text(' ',strip=True)).lower()
   if target in context:
    for tag in parent.find_all(True):
     txt=clean(tag.get_text(' ',strip=True)).lower()
     base=120 if (target in txt or 'download' in txt or 'herunterladen' in txt) else 70
     for attr,val in tag.attrs.items():
      vals=val if isinstance(val,list) else [val]
      for raw in vals:
       if isinstance(raw,str) and (raw.startswith(('http','/','//')) or '.pdf' in raw.lower() or 'asset' in raw.lower() or 'download' in raw.lower()):
        add(raw,base + (25 if str(attr).startswith('data-') else 0))
   if len(context)>12000: break
   parent=parent.parent
 # 2) Roh-HTML/JSON rund um den exakten Titel. Erfasst escaped URLs und CMS-Asset-Metadaten.
 raw=r.text; pos=raw.lower().find(target)
 if pos>=0:
  window=raw[max(0,pos-30000):pos+50000]
  patterns=[
   r'https?:\\?/\\?/[^"\'<> ]+',
   r'(?:(?:href|url|downloadUrl|downloadURL|assetUrl|assetURL|fileUrl|fileURL|src)["\']?\\s*[:=]\\s*["\'])([^"\']+)',
   r'([/][^"\'<> ]+(?:\\.pdf|/asset(?:\\?|/)|/download(?:\\?|/))[^"\'<> ]*)'
  ]
  for pat in patterns:
   for m in re.finditer(pat,window,re.I):
    val=m.group(1) if m.lastindex else m.group(0)
    add(val,95)
 # 3) Kandidaten testen; HTML-Zwischenseiten einmal nach einer echten PDF/Asset-URL auflösen.
 candidates.sort(reverse=True)
 checked=0
 for _,href in candidates[:60]:
  try:
   rr=requests.get(href,headers=headers,timeout=60,allow_redirects=True); rr.raise_for_status(); checked+=1
   if allowed_download(rr.url,manufacturer) and is_pdf_response(rr): return rr
   ctype=(rr.headers.get('content-type') or '').lower()
   if 'html' in ctype and len(rr.content)<8_000_000:
    sub=BeautifulSoup(rr.text,'html.parser')
    for tag in sub.find_all(True):
     for attr in ['href','src','data-href','data-url','data-download-url','data-file','data-src']:
      val=tag.get(attr)
      if not val: continue
      u=urljoin(rr.url,val); ul=u.lower()
      if '.pdf' not in ul and 'asset' not in ul and 'download' not in ul: continue
      try:
       r2=requests.get(u,headers=headers,timeout=60,allow_redirects=True); r2.raise_for_status()
       if allowed_download(r2.url,manufacturer) and is_pdf_response(r2): return r2
      except requests.RequestException: pass
  except requests.RequestException: pass
 raise ValueError(f'Zertifikatskarte bestätigt, aber echte PDF technisch nicht auflösbar ({checked} von {len(candidates)} Kandidat(en) geprüft).')

def resolve_rockwool_special(product, doc):
 """Dokumenttypabhängige ROCKWOOL-Resolver für Zertifikate und DoP."""
 p=product_key('rockwool',product)[1]; title=(doc or {}).get('Titel','').lower(); cat=(doc or {}).get('Kategorie','')
 if 'eurofins' in title and p=='CONLIT U':
  cfg=ROCKWOOL_DIRECT_CERTIFICATES['CONLIT U']
  return fetch_pdf_near_exact_title(cfg['eurofins_page'],'rockwool',cfg['eurofins_title'])
 if 'eurofins' in title and p=='800':
  # Verifiziertes ROCKWOOL-Asset: Indoor Air Comfort Gold für ROCKWOOL 800/810.
  headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'}
  rr=requests.get(ROCKWOOL_DIRECT_CERTIFICATES['800']['eurofins'],headers=headers,timeout=60,allow_redirects=True); rr.raise_for_status()
  if allowed_download(rr.url,'rockwool') and is_pdf_response(rr): return rr
  raise ValueError('Das verifizierte Eurofins-Zertifikat liefert aktuell keine PDF.')
 if 'blauer engel' in title:
  # Der belastbare Nachweis liegt im offiziellen Blauer-Engel-Produktregister.
  # Kein PDF vortäuschen: dieser Treffer wird in der UI als Online-Nachweis geführt.
  return None
 if cat=='Leistungserklärung (DoP)' or 'leistungserklärung' in title or 'dop' in title:
  dop=ROCKWOOL_DOP_IDS.get(p)
  if dop:
   # ROCKWOOLs deutsche DoP-Suche ist dynamisch. Die Kennung wird zuerst gegen offizielle
   # ROCKWOOL-Assets aufgelöst; bekannte Produktkennung bleibt die harte Zuordnungsbedingung.
   known={'DE0721042201':'https://www.rockwool.com/syssiteassets/rw-pl/materialy-do-pobrania/dokumentacja-produktowa/deklaracja-waciwoci-uytkowych/DoP_ROCKWOOL_800_DE0721042201.pdf.pdf'}
   if dop in known:
    headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'}
    rr=requests.get(known[dop],headers=headers,timeout=60,allow_redirects=True); rr.raise_for_status()
    if allowed_download(rr.url,'rockwool') and is_pdf_response(rr): return rr
 return None

def resolve_pdf_url(url,manufacturer,doc=None,product=''):
 """Direkte PDF verwenden; bei ROCKWOOL-HTML eine Ebene nach der echten PDF durchsuchen."""
 if not allowed_download(url,manufacturer): raise ValueError('Quelle gehört nicht zur freigegebenen Herstellerdomain.')
 headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'}
 # GROHEs ältere PDF-Generatoren blockieren einfache Script-Requests teilweise mit HTTP 403.
 # Bei GROHE senden wir deshalb normale Browser-Header + Referer und versuchen genau einmal erneut.
 if manufacturer.strip().lower()=='grohe':
  headers.update({'Accept':'application/pdf,text/html,application/xhtml+xml;q=0.9,*/*;q=0.8','Accept-Language':'de-DE,de;q=0.9,en;q=0.7','Referer':'https://www.grohe.de/','Cache-Control':'no-cache'})
 r=requests.get(url,headers=headers,timeout=60,allow_redirects=True)
 if r.status_code==403 and manufacturer.strip().lower()=='grohe':
  retry_headers=dict(headers); retry_headers['Referer']='https://www.grohe.co.za/' if 'grohe.co.za' in url.lower() else 'https://www.grohe.de/'
  r=requests.get(url,headers=retry_headers,timeout=60,allow_redirects=True)
 r.raise_for_status()
 if not allowed_download(r.url,manufacturer): raise ValueError('Weiterleitung verlässt die Herstellerdomain.')
 if is_pdf_response(r): return r
 if manufacturer.strip().lower()=='grohe':
  soup=BeautifulSoup(r.text,'html.parser'); candidates=[]; seen=set()
  for a in soup.find_all('a',href=True):
   href=urljoin(r.url,a['href']); blob=(clean(a.get_text(' ',strip=True))+' '+href).lower()
   if href in seen or not allowed_download(href,'grohe'): continue
   seen.add(href)
   if '.pdf' in blob or 'download' in blob:
    candidates.append(href)
  for href in candidates[:20]:
   try:
    rr=requests.get(href,headers=headers,timeout=60,allow_redirects=True); rr.raise_for_status()
    if allowed_download(rr.url,'grohe') and is_pdf_response(rr): return rr
   except requests.RequestException: pass
  raise ValueError(f'GROHE-Link liefert noch keine echte PDF ({len(candidates)} Download-Kandidat(en) geprüft).')
 if manufacturer.strip().lower()!='rockwool': raise ValueError('Link liefert keine PDF-Datei.')
 special=resolve_rockwool_special(product,doc or {})
 if special is not None: return special

 soup=BeautifulSoup(r.text,'html.parser'); candidates=[]; seen=set()
 wanted_cat=(doc or {}).get('Kategorie',''); wanted_title=(doc or {}).get('Titel','').lower()
 for a in soup.find_all('a',href=True):
  href=urljoin(r.url,a['href']); host=urlparse(href).netloc.lower(); title=clean(a.get_text(' ',strip=True)); blob=(title+' '+href).lower()
  if 'rockwool.com' not in host or href in seen: continue
  seen.add(href)
  # Nur echte/naheliegende Dokumentdownloads verfolgen, keine Navigation.
  if rockwool_noise(title,href): continue
  if not ('.pdf' in blob or 'download' in blob or 'herunterladen' in blob): continue
  cat=classify(title,href,'rockwool')
  score=0
  if '.pdf' in blob: score+=50
  if cat==wanted_cat and cat!='Sonstiges': score+=35
  if any(x in blob for x in ['download','herunterladen']): score+=10
  if wanted_title and any(w in blob for w in wanted_title.split() if len(w)>5): score+=5
  candidates.append((score,href))
 candidates.sort(reverse=True)
 errors=[]
 for _,href in candidates[:12]:
  try:
   rr=requests.get(href,headers=headers,timeout=60,allow_redirects=True); rr.raise_for_status()
   if allowed_download(rr.url,manufacturer) and is_pdf_response(rr): return rr
  except requests.RequestException as e: errors.append(str(e))
 raise ValueError(f'Keine echte PDF auf der ROCKWOOL-Folgeseite gefunden ({len(candidates)} Download-Kandidat(en) geprüft).')

def download(project,m,p,d):
 r=resolve_pdf_url(d['URL'],m,d,p)
 data=r.content
 folder=os.path.join(DOWNLOAD_ROOT,safe(project),safe(m),safe(p)); os.makedirs(folder,exist_ok=True); raw=os.path.basename(urlparse(r.url).path) or safe(d['Titel'])+'.pdf'
 if not raw.lower().endswith('.pdf'):raw+='.pdf'
 path=os.path.join(folder,safe(raw[:-4])+'.pdf')
 if os.path.exists(path): path=os.path.splitext(path)[0]+'_'+hashlib.sha1(r.url.encode()).hexdigest()[:8]+'.pdf'
 with open(path,'wb') as f:f.write(data)
 return path,len(data),r.url

def google_url(m,p,a=''):
 domain=DOMAINS.get(m.lower(),''); q=' '.join(x for x in [m,p,a] if x); q=(f'site:{domain} '+q) if domain else q
 return 'https://www.google.com/search?q='+urllib.parse.quote(q)


APP_VERSION = "2.3.6"
# Dieser Endpunkt wird aktiviert, sobald ein fester Update-Speicher eingerichtet ist.
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/FabienneBoese/TGA-Product-Finder-Updates/main/update_manifest.json"
UPDATE_CHANNEL_FILE = Path.home() / "AppData" / "Local" / "TGA Product Finder" / "update_channel.json"

def _get_update_manifest_url():
    """Read the update channel without touching project data."""
    try:
        if UPDATE_CHANNEL_FILE.exists():
            cfg = json.loads(UPDATE_CHANNEL_FILE.read_text(encoding="utf-8"))
            return str(cfg.get("manifest_url", "")).strip()
    except Exception:
        pass
    return UPDATE_MANIFEST_URL


def _version_tuple(value):
    try:
        return tuple(int(x) for x in str(value).strip().lstrip("v").split("."))
    except Exception:
        return (0,)


def download_update_package(download_url, expected_sha256=""):
    """Download an update package and verify its SHA256 when supplied."""
    r = requests.get(download_url, timeout=60)
    r.raise_for_status()
    data = r.content
    actual_sha256 = hashlib.sha256(data).hexdigest().lower()
    expected = str(expected_sha256 or "").strip().lower()
    if expected and actual_sha256 != expected:
        raise ValueError("Sicherheitsprüfung fehlgeschlagen: SHA256 stimmt nicht überein.")
    update_dir = Path(tempfile.gettempdir()) / "TGA_Product_Finder_Update"
    update_dir.mkdir(parents=True, exist_ok=True)
    target = update_dir / "TGA_Product_Finder_Update.zip"
    target.write_bytes(data)
    return target, actual_sha256

def install_downloaded_update(zip_path):
    """Start the standalone PowerShell updater directly, without a CMD bridge."""
    import subprocess
    package = Path(zip_path).resolve()
    root = Path.home() / "AppData" / "Local" / "TGA Product Finder"
    updater = root / "TGA_Updater.ps1"
    start_log = root / "updater_start.log"

    if not package.exists():
        raise FileNotFoundError(f"Update-Paket fehlt: {package}")
    if not updater.exists():
        raise FileNotFoundError(f"Windows-Updater fehlt: {updater}")

    start_log.write_text(
        "Direktstart vorbereitet.\n"
        f"Updater: {updater}\n"
        f"Package: {package}\n",
        encoding="utf-8"
    )

    cmd = [
        "powershell.exe",
        "-NoLogo",
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", str(updater),
        "-Package", str(package),
    ]
    flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
    process = subprocess.Popen(
        cmd,
        cwd=str(root),
        creationflags=flags,
        close_fds=False,
    )
    start_log.write_text(
        start_log.read_text(encoding="utf-8") +
        f"PowerShell-Prozess gestartet. PID: {process.pid}\n",
        encoding="utf-8"
    )
    return updater

def check_for_update():
    """Read the manifest through GitHub's API to avoid stale raw-CDN data."""
    import base64
    manifest_url = _get_update_manifest_url()
    if not manifest_url:
        return {"configured": False, "current": APP_VERSION}

    headers = {
        "Accept": "application/vnd.github+json",
        "Cache-Control": "no-cache, no-store, max-age=0",
        "Pragma": "no-cache",
        "User-Agent": "TGA-Product-Finder-Updater",
    }
    api = "https://api.github.com/repos/FabienneBoese/TGA-Product-Finder-Updates/contents/update_manifest.json"
    info = None
    errors = []
    source = ""

    try:
        r = requests.get(f"{api}?ref=main&t={time.time_ns()}", timeout=10, headers=headers)
        r.raise_for_status()
        payload = r.json()
        encoded = str(payload.get("content", "")).replace("\n", "")
        info = json.loads(base64.b64decode(encoded).decode("utf-8"))
        source = "GitHub API"
    except Exception as exc:
        errors.append(f"GitHub API: {exc}")

    if info is None:
        try:
            sep = "&" if "?" in manifest_url else "?"
            r = requests.get(
                f"{manifest_url}{sep}t={time.time_ns()}",
                timeout=10,
                headers=headers,
            )
            r.raise_for_status()
            info = r.json()
            source = "Raw-Fallback"
        except Exception as exc:
            errors.append(f"Raw: {exc}")
            return {"configured": True, "current": APP_VERSION, "error": " | ".join(errors)}

    latest = str(info.get("version", "")).strip()
    url = str(info.get("download_url", "")).strip()
    sha256 = str(info.get("sha256", "")).strip().lower()
    return {
        "configured": True,
        "current": APP_VERSION,
        "latest": latest,
        "server_version": latest,
        "download_url": url,
        "sha256": sha256,
        "source": source,
        "available": bool(latest and url and _version_tuple(latest) > _version_tuple(APP_VERSION)),
    }


st.set_page_config(page_title='TGA Product Finder 1.0.3',page_icon='🏗️',layout='wide')
st.title(f'🏗️ TGA Product Finder · Version {APP_VERSION}')
st.caption('Intelligente Dokumentenmappe · projektbezogene Offline-Dokumente')

with st.sidebar:
    st.header("Programm")
    st.write(f"Installierte Version: **v{APP_VERSION}**")
    if st.button("Nach Updates suchen", key="check_app_update"):
        st.session_state["update_check"] = check_for_update()
    _u = st.session_state.get("update_check")
    if _u:
        if not _u.get("configured"):
            st.info("Die Update-Funktion ist aktiv. Der feste Online-Updatekanal ist noch nicht verbunden.")
        elif _u.get("error"):
            st.warning("Update-Prüfung derzeit nicht möglich.")
        elif _u.get("available"):
            st.success(f"Neue Version verfügbar: v{_u.get('latest')}")
            if st.button("Update herunterladen", key="download_app_update"):
                try:
                    _path, _hash = download_update_package(_u.get("download_url"), _u.get("sha256"))
                    st.session_state["downloaded_update_path"] = str(_path)
                    st.success("Update wurde heruntergeladen und geprüft.")
                    st.info("Das Update ist bereit zur Installation.")
                    if False and st.button("Update jetzt installieren", key="install_downloaded_app_update_legacy"):
                        try:
                            install_downloaded_update(_path)
                            st.success("Installer gestartet. Das Update-Fenster übernimmt jetzt die Installation.")
                            st.info("Deine Projektdaten im Data-Ordner bleiben unangetastet.")
                        except Exception as exc:
                            st.error(f"Update konnte nicht installiert werden: {exc}")
                except Exception as exc:
                    st.error(f"Update konnte nicht heruntergeladen werden: {exc}")
        else:
            st.success("Du verwendest die aktuelle Version.")

# v1.3.9: dauerhafter Update-Installationsbereich.
# Der Downloadpfad wird unabhängig vom Download-Button auf jeder Streamlit-Ausführung geprüft.
_update_package = st.session_state.get("downloaded_update_path")
if _update_package:
    _update_package_path = Path(_update_package)
    if _update_package_path.exists():
        st.sidebar.markdown("---")
        st.sidebar.subheader("Programmupdates")
        st.sidebar.success("Update heruntergeladen und geprüft")
        
        if st.sidebar.button(
            "Update jetzt installieren",
            key="persistent_update_install_v205",
            type="primary",
            use_container_width=True,
        ):
            try:
                _started = install_downloaded_update(_update_package_path)
                st.sidebar.success("Windows-Updater wurde direkt gestartet.")
                st.sidebar.info("Bitte das geöffnete Update-Fenster nicht schließen. Die App wird anschließend neu gestartet.")
            except Exception as exc:
                st.sidebar.error(f"Update konnte nicht gestartet werden: {exc}")
    else:
        st.session_state.pop("downloaded_update_path", None)



# v1.4.0: Projektverwaltung – alte Projekte werden aus Komponenten übernommen.
with db() as project_db:
 existing_projects=[r[0] for r in project_db.execute('SELECT name FROM projects ORDER BY name COLLATE NOCASE').fetchall()]
if not existing_projects:
 with db() as project_db:
  project_db.execute('INSERT OR IGNORE INTO projects(name) VALUES(?)',('Testprojekt',))
 existing_projects=['Testprojekt']
if st.session_state.get('active_tga_project') not in existing_projects:
 st.session_state['active_tga_project']=existing_projects[0]
project=st.sidebar.selectbox('Aktives Bauprojekt',existing_projects,index=existing_projects.index(st.session_state['active_tga_project']),key='tga_project_selector')
st.session_state['active_tga_project']=project
st.sidebar.markdown('---')
st.sidebar.subheader('Navigation')
_tga_page=st.sidebar.radio('Bereich öffnen', ['🏗️ Projektverwaltung','📊 Dokumentenübersicht','📁 Projektunterlagen'],key='tga_navigation',label_visibility='collapsed')
if _tga_page=='🏗️ Projektverwaltung':
 st.subheader('🏗️ Projektverwaltung')
 with st.expander('➕ Neues Bauprojekt anlegen'):
  with st.form('create_tga_project',clear_on_submit=True):
   new_project=st.text_input('Projektbezeichnung',placeholder='z. B. Neubau Schule Nord')
   create_project=st.form_submit_button('Projekt anlegen',type='primary')
  if create_project:
   new_project=new_project.strip()
   if not new_project: st.error('Bitte eine Projektbezeichnung eingeben.')
   elif new_project in existing_projects: st.warning('Dieses Projekt ist bereits vorhanden.')
   elif len(new_project)>100 or any(x in new_project for x in ('/','\\')) or new_project in ('.','..'):
    st.error('Bitte einen kürzeren Projektnamen ohne Schrägstriche verwenden.')
   else:
    with db() as project_db:
     project_db.execute('INSERT INTO projects(name) VALUES(?)',(new_project,))
    st.session_state['active_tga_project']=new_project
    st.success('Projekt angelegt.')
    st.rerun()
 st.caption('Jedes Projekt hat eine eigene Komponentenliste und Dokumentenmappe. Bestehende Projektdaten bleiben erhalten.')
 # v1.0.1: Gespeicherten Projektbestand sichtbar machen; Excel ist nur Import/Aktualisierung.
 try:
  con_saved=db()
  saved_count=con_saved.execute('SELECT COUNT(*) FROM components WHERE project=?',(project,)).fetchone()[0]
  con_saved.close()
 except Exception:
  saved_count=0
 if saved_count:
  st.success(f'Gespeichertes Projekt geladen: {saved_count} Komponenten. Kein erneuter Excel-Upload nötig.')
  with st.expander('Excel-Datei importieren / Projektbestand aktualisieren'):
   st.warning('Achtung: Beim Übernehmen einer neuen Excel-Liste werden die bisherigen Produktzuordnungen und Dokumentverknüpfungen dieses Projekts ersetzt. Andere Projekte bleiben unverändert.')
   upload=st.file_uploader('Komponentenliste auswählen',type=['xlsx'],key=f'project_excel_update_{project}')
 else:
  st.info('Für dieses Projekt ist noch keine Komponentenliste gespeichert. Bitte einmalig eine Excel-Datei importieren.')
  upload=st.file_uploader('Komponentenliste hochladen',type=['xlsx'],key=f'project_excel_initial_{project}')
 if upload:
  try:
   df=read_excel(upload.getvalue()); df['Erkennung %']=df.apply(score,axis=1); df['Status']=df['Erkennung %'].map(status); st.success(f'{len(df)} Komponenten erkannt.'); st.dataframe(df,width='stretch',hide_index=True)
   if st.button('Komponenten in Projekt übernehmen',type='primary'):
    con=db(); old_ids=[x[0] for x in con.execute('SELECT id FROM components WHERE project=?',(project,)).fetchall()]
    for old_id in old_ids:
     con.execute('DELETE FROM documents WHERE component_id=?',(old_id,)); con.execute('DELETE FROM component_selections WHERE component_id=?',(old_id,)); con.execute('DELETE FROM component_application_groups WHERE component_id=?',(old_id,))
    con.execute('DELETE FROM components WHERE project=?',(project,))
    for _,r in df.iterrows():
     _typ,_article,_kind=classify_component_identifier(r.Hersteller,r.Bezeichnung,r.Artikelnummer)
     _input_type=clean(r['Typ / Modell'])
     _candidate_type,_candidate_article,_kind=classify_component_identifier(r.Hersteller,r.Bezeichnung,r.Artikelnummer)
     _final_type=_input_type or (_candidate_type if _kind in ('type','type_candidate') else '')
     _final_article=(_candidate_article if _kind!='family' else '') if not _input_type else ('' if _kind=='family' else clean(r.Artikelnummer))
     con.execute('INSERT INTO components(project,manufacturer,product,article_no,model_type,confidence,status,docs_searched,gewerk) VALUES(?,?,?,?,?,?,?,0,?)',(project,r.Hersteller,r.Bezeichnung,_final_article,_final_type,score(r),status(score(r)),r.Gewerk))
     con.execute('UPDATE components SET identifier_source=?,product_family=? WHERE id=?',(clean(r.Artikelnummer),clean(r.Artikelnummer) if _kind=='family' else '',con.execute('SELECT last_insert_rowid()').fetchone()[0]))
    con.commit(); st.success('Projekt gespeichert.'); st.rerun()
  except Exception as e:st.error(str(e))
con=db(); rows=con.execute('SELECT id,manufacturer,product,article_no,confidence,status,docs_searched FROM components WHERE project=? ORDER BY id',(project,)).fetchall()
def refresh_project_upload_links(con,project):
 """Re-evaluate stored file evidence against the current component inventory."""
 import hashlib
 from pathlib import Path
 import pandas as pd
 import io,zipfile,xml.etree.ElementTree as ET
 con.execute('CREATE TABLE IF NOT EXISTS project_uploads(id INTEGER PRIMARY KEY,project TEXT NOT NULL,filename TEXT NOT NULL,sha256 TEXT NOT NULL,path TEXT NOT NULL,uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(project,sha256))')
 con.execute('CREATE TABLE IF NOT EXISTS project_upload_links(upload_id INTEGER NOT NULL,component_id INTEGER NOT NULL,score INTEGER NOT NULL,confirmed INTEGER DEFAULT 0,PRIMARY KEY(upload_id,component_id))')
 items=con.execute('SELECT id,filename,path FROM project_uploads WHERE project=?',(project,)).fetchall()
 components=con.execute('SELECT id,manufacturer,product,article_no FROM components WHERE project=?',(project,)).fetchall()
 norm=lambda x:''.join(c for c in str(x or '').lower() if c.isalnum())
 for uid,name,path in items:
  if not os.path.isfile(path):continue
  content=''
  ext=Path(name).suffix.lower()
  try:
   if ext=='.txt':content=Path(path).read_text(encoding='utf-8',errors='replace')
   elif ext=='.pdf':
    from pypdf import PdfReader
    reader=PdfReader(path);content=' '.join((page.extract_text() or '') for page in reader.pages[:50])
   elif ext in ('.xlsx','.xlsm'):
    sheets=pd.read_excel(path,sheet_name=None,header=None,nrows=500)
    content=' '.join(' '.join(df.fillna('').astype(str).to_numpy().flatten()) for df in sheets.values())
   elif ext=='.docx':
    with zipfile.ZipFile(path) as archive:
     xml=ET.fromstring(archive.read('word/document.xml'))
     content=' '.join(n.text or '' for n in xml.iter() if n.tag.endswith('}t'))
  except Exception:pass
  hay=norm(name+' '+content[:250000])
  for cid,m,p,a in components:
   manufacturer=norm(m)
   article=norm(a)
   product=norm(p)
   score=0
   manufacturer_found=len(manufacturer)>=4 and manufacturer in hay
   article_found=len(article)>=5 and article in hay
   product_found=len(product)>=7 and product in hay
   if manufacturer_found:score+=25
   if article_found:score+=65
   if product_found:score+=35
   # Article/model match without a matching manufacturer can be ambiguous.
   if not manufacturer_found and not product_found:score=min(score,59)
   if score>=60:
    con.execute('INSERT INTO project_upload_links(upload_id,component_id,score,confirmed) VALUES(?,?,?,0) ON CONFLICT(upload_id,component_id) DO UPDATE SET score=excluded.score',(uid,cid,min(score,100)))
  con.execute('DELETE FROM project_upload_links WHERE upload_id=? AND component_id NOT IN (SELECT id FROM components WHERE project=?)',(uid,project))
 con.commit()

def project_uploads_for_component(con,project,cid):
 """One visible row per binary content, regardless of upload filename."""
 import hashlib
 files=con.execute('SELECT u.id,u.filename,u.path,u.sha256,l.score,l.confirmed FROM project_uploads u JOIN project_upload_links l ON l.upload_id=u.id WHERE u.project=? AND l.component_id=? ORDER BY l.score DESC',(project,cid)).fetchall()
 known=set()
 for (path,) in con.execute('SELECT local_path FROM documents WHERE component_id=? AND local_path IS NOT NULL AND local_path != ""',(cid,)):
  if os.path.isfile(path):
   try:
    with open(path,'rb') as stream:known.add(hashlib.sha256(stream.read()).hexdigest())
   except OSError:pass
 result=[]
 for item in files:
  if item[3] not in known and os.path.isfile(item[2]):
   result.append(item);known.add(item[3])
 return result

if _tga_page=='📁 Projektunterlagen':
 st.subheader('📁 Projektunterlagen')
 st.caption('Alle individuellen Unterlagen zentral hochladen. Vorschläge werden anhand der Komponentenliste erstellt; fachliche Freigabe erfolgt getrennt.')
 con.execute('CREATE TABLE IF NOT EXISTS project_uploads(id INTEGER PRIMARY KEY,project TEXT NOT NULL,filename TEXT NOT NULL,sha256 TEXT NOT NULL,path TEXT NOT NULL,uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(project,sha256))')
 con.execute('CREATE TABLE IF NOT EXISTS project_upload_links(upload_id INTEGER NOT NULL,component_id INTEGER NOT NULL,score INTEGER NOT NULL,confirmed INTEGER DEFAULT 0,PRIMARY KEY(upload_id,component_id))')
 con.commit()
 _uploads=st.file_uploader('Projektdateien gesammelt hochladen',type=['pdf','xlsx','xlsm','docx','txt'],accept_multiple_files=True,key=f'project_uploads_{project}')
 if _uploads and st.button('Dateien speichern und automatisch zuordnen',key=f'process_uploads_{project}'):
  import io,zipfile,xml.etree.ElementTree as ET
  _messages=[]
  _base=os.path.join(DATA_ROOT,'ProjectUploads',safe(project))
  os.makedirs(_base,exist_ok=True)
  for _up in _uploads:
   try:
    _bytes=_up.getvalue()
    if not _bytes or len(_bytes)>30*1024*1024:raise ValueError('Datei leer oder größer als 30 MB.')
    _suffix=Path(_up.name).suffix.lower()
    _digest=hashlib.sha256(_bytes).hexdigest()
    _name=safe(Path(_up.name).stem)[:80]+_suffix
    _target=os.path.join(_base,_digest[:16]+'_'+_name)
    _existing=con.execute('SELECT id FROM project_uploads WHERE project=? AND sha256=?',(project,_digest)).fetchone()
    if _existing:_uid=_existing[0]
    else:
     with open(_target,'wb') as _out:_out.write(_bytes)
     _uid=con.execute('INSERT INTO project_uploads(project,filename,sha256,path) VALUES(?,?,?,?)',(project,_up.name,_digest,_target)).lastrowid
    _content=''
    if _suffix=='.pdf':
     try:
      from pypdf import PdfReader
      _reader=PdfReader(io.BytesIO(_bytes))
      _content=' '.join((page.extract_text() or '') for page in _reader.pages[:50])
     except ImportError:
      _messages.append(_up.name+': PDF-Texterkennung nicht verfügbar; Dateiname wird abgeglichen.')
    elif _suffix in ('.xlsx','.xlsm'):
     _frame=pd.read_excel(io.BytesIO(_bytes),sheet_name=None,header=None,nrows=500)
     _content=' '.join(' '.join(df.fillna('').astype(str).to_numpy().flatten()) for df in _frame.values())
    elif _suffix=='.txt':_content=_bytes.decode('utf-8',errors='replace')
    elif _suffix=='.docx':
     with zipfile.ZipFile(io.BytesIO(_bytes)) as _archive:
      _xml=ET.fromstring(_archive.read('word/document.xml'))
      _content=' '.join(x.text or '' for x in _xml.iter() if x.tag.endswith('}t'))
    _hay=(' '+_up.name+' '+_content[:250000]+' ').lower()
    _norm=lambda value: ''.join(ch for ch in str(value or '').lower() if ch.isalnum())
    _compact=_norm(_hay)
    con.execute('DELETE FROM project_upload_links WHERE upload_id=? AND confirmed=0',(_uid,))
    for _cid,_m,_p,_a,*_rest in rows:
     _manufacturer=_norm(_m);_model=_norm(_a);_product=_norm(_p)
     _score=0
     if _manufacturer and len(_manufacturer)>=4 and _manufacturer in _compact:_score+=25
     if _model and len(_model)>=5 and _model in _compact:_score+=65
     if _product and len(_product)>=7 and _product in _compact:_score+=35
     if _score>=60:
      con.execute('INSERT OR IGNORE INTO project_upload_links(upload_id,component_id,score,confirmed) VALUES(?,?,?,0)',(_uid,_cid,min(_score,100)))
    _messages.append(_up.name+': gespeichert und abgeglichen.')
   except Exception as _exc:_messages.append(_up.name+': Fehler – '+str(_exc))
  con.commit()
  for _message in _messages:st.write(_message)
 _stored=con.execute('SELECT id,filename,path FROM project_uploads WHERE project=? ORDER BY id DESC',(project,)).fetchall()
 refresh_project_upload_links(con,project)
 st.markdown('**Gespeicherte Projektdateien und Zuordnungsvorschläge**')
 if not _stored:st.info('Noch keine individuellen Projektdateien hochgeladen.')
 for _uid,_filename,_path in _stored:
  with st.expander(_filename):
   if os.path.isfile(_path):
    with open(_path,'rb') as _stream:st.download_button('Datei öffnen / herunterladen',_stream.read(),file_name=_filename,key=f'upload_file_{_uid}')
   _matches=con.execute('SELECT l.component_id,c.manufacturer,c.product,c.article_no,l.score,l.confirmed FROM project_upload_links l JOIN components c ON c.id=l.component_id WHERE l.upload_id=? AND c.project=? ORDER BY l.score DESC',(_uid,project)).fetchall()
   if not _matches:st.info('Keine eindeutige Produktzuordnung erkannt. Datei bleibt im Projektarchiv.')
   for _cid,_m,_p,_a,_score,_confirmed in _matches:
    _left,_right=st.columns([4,1])
    _left.write(f'{_m} · {_p} · {_a or "ohne Typ"} – {_score}% Übereinstimmung')
    if _right.checkbox('Bestätigt',value=bool(_confirmed),key=f'upload_confirm_{_uid}_{_cid}'):
     if not _confirmed:con.execute('UPDATE project_upload_links SET confirmed=1 WHERE upload_id=? AND component_id=?',(_uid,_cid));con.commit()
    elif _confirmed:con.execute('UPDATE project_upload_links SET confirmed=0 WHERE upload_id=? AND component_id=?',(_uid,_cid));con.commit()

 # Exact Helios match only; existing article numbers are protected.
if _tga_page=='📊 Dokumentenübersicht':

 _helios_rows=con.execute("SELECT id,manufacturer,product,model_type,article_no FROM components WHERE project=?",(project,)).fetchall()
 for _hid,_hm,_hp,_ht,_ha in _helios_rows:
  _candidate=helios_official_article(_hm,_hp,_ht,_ha)
  if _candidate and not _candidate['conflict'] and not str(_ha or '').strip():
   con.execute("UPDATE components SET article_no=? WHERE id=? AND (article_no IS NULL OR TRIM(article_no)='')",(_candidate['article'],_hid))
 con.commit()
 rows=con.execute("SELECT id,manufacturer,product,article_no,confidence,status,docs_searched FROM components WHERE project=? ORDER BY id",(project,)).fetchall()
 refresh_project_upload_links(con,project)
 st.subheader('📊 Dokumentenübersicht')
 if rows:
  st.divider(); st.subheader('📊 Projekt-Dokumentationsübersicht')
  # Die Übersicht trennt Produkterkennung bewusst vom Dokumentationsstand.
  st.markdown('#### Dokumentationsumfang festlegen')
  st.caption('Eine Produktfamilie kann gemeinsam dokumentiert werden. Einzelartikel werden nur nach konkreter Herstellerprüfung ausgewählt; hier werden keine Artikelnummern erfunden.')
  _scope_rows=con.execute('SELECT id,manufacturer,product,product_family,documentation_scope,component_category,dimensions_grouped FROM components WHERE project=? ORDER BY id',(project,)).fetchall()
  if _scope_rows:
   _scope_map={f'{r[1]} | {r[2]} | ID {r[0]}':r for r in _scope_rows}
   _selected_index=None
   try:
    _selected_rows=st.session_state.get('doc_overview_selection',{}).get('selection',{}).get('rows',[])
    if _selected_rows:
     _selected_index=int(_selected_rows[0])
   except (TypeError,ValueError,AttributeError,IndexError):
    pass
   _scope_labels=list(_scope_map)
   _selected_label=None
   if _selected_index is not None and 0<=_selected_index<len(rows):
    _selected_id=rows[_selected_index][0]
    _selected_label=next((label for label,item in _scope_map.items() if item[0]==_selected_id),None)
    _scope_label=_selected_label if _selected_label in _scope_map else _scope_labels[0]
    st.caption('Ausgewählte Tabellenzeile: '+_scope_label+' · Zum Wechseln eine andere Tabellenzeile anklicken.')
   _scope_label=_selected_label if _selected_label in _scope_map else next(iter(_scope_map))
   _scope_item=_scope_map[_scope_label]
   _scope_id=_scope_item[0]
   _helios_row=con.execute('SELECT manufacturer,product,model_type,article_no FROM components WHERE id=?',(_scope_id,)).fetchone()
   if _helios_row:
    _helios_match=helios_official_article(*_helios_row)
    if _helios_match:
     st.caption('Helios-Herstellerquelle: '+_helios_match['source'])
     if _helios_match['conflict']:
      st.warning('Artikelnummer weicht von Helios 09506 ab; vorhandenen Wert bitte prüfen.')
     elif not str(_helios_row[3] or '').strip():
      st.info('Herstellerartikelnummer 09506 erkannt (Helios SB 125 A).')
   _scope_options=['Produktfamilie / gemeinsame Dokumente','Einzelartikel / Variante prüfen']
   _scope_existing=1 if str(_scope_item[4] or '').startswith('Einzelartikel') else 0
   _scope_choice=st.radio('Dokumentationsumfang',_scope_options,index=_scope_existing,key=f'doc_scope_mode_{_scope_id}')
   _product_text=str(_scope_item[2] or '')
   _suggested_category=next((term for term in ('Systemrohr','Schiebemuffe','Muffe','Bogen','T-Stück','Reduzierung') if term.casefold() in _product_text.casefold()),'')
   _dimension_tokens=re.findall(r'(?<![A-Za-z0-9])(?:DN\s*)?(?:12|15|16|18|20|22|25|28|32|35|40|42|50|54|63|65|76|88|100|108)(?![A-Za-z0-9])',_product_text,re.I)
   _suggested_dimensions=', '.join(dict.fromkeys(re.sub(r'(?i)^DN\s*','',v) for v in _dimension_tokens))
   if _suggested_category or _suggested_dimensions:
    st.caption('Vorschlag aus Produktbezeichnung (bitte vor dem Speichern prüfen): '+(_suggested_category or 'Bauteilart offen')+' | '+(_suggested_dimensions or 'Dimension offen'))
   _scope_category=st.text_input('Bauteilart (z. B. Systemrohr, Muffe)',value=_scope_item[5] or _suggested_category,key=f'doc_scope_category_{_scope_id}')
   _scope_dimensions=st.text_input('Zusammengefasste Dimensionen (z. B. 15, 22, 28)',value=_scope_item[6] or _suggested_dimensions,key=f'doc_scope_dimensions_{_scope_id}')
   if _scope_choice.startswith('Einzelartikel'):
    st.info('Die konkrete Artikelnummer wird erst nach Herstellerabgleich bestätigt. Die bestehende Kennung wird nicht automatisch geändert.')
   if st.button('Dokumentationsumfang speichern',key='doc_scope_save'):
    con.execute('UPDATE components SET documentation_scope=?,component_category=?,dimensions_grouped=? WHERE id=?',(_scope_choice,_scope_category.strip(),_scope_dimensions.strip(),_scope_id))
    con.commit()
    st.success('Dokumentationsumfang gespeichert. Bestehende Dokumente und Artikelnummern bleiben erhalten.')
  st.divider()
  overview=[]
  for ocid,om,op,oa,oconf,ostat,osearched in rows:
   odb=con.execute('SELECT priority,verified,local_path,download_status,project_confirmed FROM documents WHERE component_id=?',(ocid,)).fetchall()
   ooffline=sum(1 for _,_,opath,_,_ in odb if opath and os.path.exists(opath))
   oonline=sum(1 for prio,verified,opath,dstatus,_ in odb if prio=='Empfohlen' and verified and not (opath and os.path.exists(opath)))
   orecommended=sum(1 for prio,_,_,_,_ in odb if prio=='Empfohlen')
   ocheck=sum(1 for prio,_,_,_,confirmed in odb if prio in ['Anwendungsfall prüfen','Optional / Ausführung prüfen'] and not confirmed)
   docstatus=documentation_light(bool(osearched or ooffline),odb)
   selections=get_component_selections(con,ocid)
   _verified_name,_name_ok,_model=con.execute('SELECT manufacturer_product_name,product_name_confirmed,model_type FROM components WHERE id=?',(ocid,)).fetchone()
   _display_name=_verified_name if _name_ok and str(_verified_name or '').strip() else op
   _verified_name,_name_ok,_model=con.execute('SELECT manufacturer_product_name,product_name_confirmed,model_type FROM components WHERE id=?',(ocid,)).fetchone()
   _display_name=_verified_name if _name_ok and str(_verified_name or '').strip() else op
   overview.append({'Status':docstatus.split()[0],'Hersteller':om,'Bezeichnung':_display_name,'Typ / Modell':_model or '—','Artikelnummer':oa or '—','Herstellerquelle':helios_official_article(om,op,'',oa)['source'] if helios_official_article(om,op,'',oa) else '—','Produktfamilie':(con.execute('SELECT product_family FROM components WHERE id=?',(ocid,)).fetchone()[0] or '—'),'Kennung prüfen':'⚠️' if oa and classify_component_identifier(om,op,oa)[2]=='unclassified' else '','Datenvollständigkeit %':min(45+(20 if om else 0)+(20 if op else 0)+(15 if oa or _model else 0),100),'Produktidentifikation':('Herstellerbezeichnung bestätigt; Variante prüfen' if _name_ok else 'Herstellerprüfung offen'),'Produkterkennung':('Produktfamilie erkannt – Variante prüfen' if con.execute('SELECT product_family FROM components WHERE id=?',(ocid,)).fetchone()[0] else ('Kennung unklar – prüfen' if oa and classify_component_identifier(om,op,oa)[2]=='unclassified' else ('Typ erkannt – Herstellerprüfung offen' if _model else ('Artikelnummer vorhanden – Herstellerprüfung offen' if oa else 'Angaben unvollständig – prüfen')))),'Empfohlen':orecommended,'Offline-PDFs':ooffline,'Online-Nachweise':oonline,'Prüfen':ocheck})
  ovdf=pd.DataFrame(overview)
  total=len(overview); auto_ok=sum(1 for x in overview if x['Datenvollständigkeit %']>=95); need_confirm=total-auto_ok
  searched=sum(1 for x in overview if not x['Status'].startswith('🔴')); offline=sum(x['Offline-PDFs'] for x in overview); online=sum(x['Online-Nachweise'] for x in overview); checks=sum(x['Prüfen'] for x in overview)
  k1,k2,k3,k4,k5=st.columns(5)
  k1.metric('Bauteile',total); k2.metric('≥95 % Datenfelder',auto_ok); k3.metric('Datenfelder unter 95 %',need_confirm); k4.metric('Offline-PDFs',offline); k5.metric('Online-Nachweise',online)
  st.caption(f'Dokumentensuche ausgeführt: {searched} von {total} Bauteilen · offene fachliche Prüfungen: {checks}. Status: 🔴 noch nicht bearbeitet · 🟡 Prüfung/offene Unterlagen · 🟢 Dokumentation geklärt.')
  st.dataframe(ovdf, height=max(420, 38 * (len(ovdf) + 1)), use_container_width=True, hide_index=True, on_select='rerun', selection_mode='single-row', key='doc_overview_selection')
 st.subheader('📁 Offline-Dokumente dieses Projekts')
 st.caption('Nur tatsächlich gespeicherte PDF-Dateien werden hier als offline verfügbar angezeigt. Online-Nachweise bleiben online.')
 _offline_rows=con.execute("SELECT c.manufacturer,c.product,d.doc_type,d.title,d.local_path FROM documents d JOIN components c ON c.id=d.component_id WHERE c.project=? AND d.local_path IS NOT NULL AND d.local_path != '' ORDER BY c.manufacturer,c.product,d.doc_type",(project,)).fetchall()
 _offline_valid=[(m,p,typ,title,path) for m,p,typ,title,path in _offline_rows if os.path.isfile(path)]
 if not _offline_valid:
  st.info('Für dieses Projekt sind noch keine Offline-PDFs gespeichert.')
 else:
  st.success(f'{len(_offline_valid)} Offline-PDF(s) für dieses Projekt vorhanden.')
  for _idx,(_m,_p,_typ,_title,_path) in enumerate(_offline_valid):
   _left,_right=st.columns([4,1])
   _left.write(f'**{_m} · {_p}** – {_typ}: {_title}')
   with open(_path,'rb') as _pdf:
    _right.download_button('PDF öffnen / speichern',data=_pdf.read(),file_name=Path(_path).name,mime='application/pdf',key=f'project_offline_{_idx}_{project}')
 st.divider(); st.subheader('Komponenten & Dokumentenmappen'); st.info('Automatisch freigeschaltet: TROX FK2-EU/TVE sowie ROCKWOOL 800/Conlit U. „Empfohlen“ ist eine regelbasierte Vorauswahl; Sonderausführungen und ROCKWOOL-Anwendbarkeitsnachweise müssen fachlich zum Einbau passen.')
 for cid,m,p,a,conf,stat,docs_searched in rows:
  with st.expander(f'{m} · {p}'+(f' · {a}' if a else '')+f' — {conf}%'):
   _current_model=con.execute('SELECT model_type FROM components WHERE id=?',(cid,)).fetchone()[0] or ''
   _new_model=st.text_input('Typ / Modell (getrennt von Artikelnummer)',value=_current_model,key=f'model_type_{cid}')
   if _new_model.strip()!=_current_model.strip():
    if st.button('Typ / Modell speichern',key=f'save_model_{cid}'):
     con.execute('UPDATE components SET model_type=? WHERE id=?',(_new_model.strip(),cid));con.commit();st.rerun()
   _current_model=con.execute('SELECT model_type FROM components WHERE id=?',(cid,)).fetchone()[0] or ''
   _new_model=st.text_input('Typ / Modell (getrennt von Artikelnummer)',value=_current_model,key=f'model_type_{cid}')
   if _new_model.strip()!=_current_model.strip():
    if st.button('Typ / Modell speichern',key=f'save_model_{cid}'):
     con.execute('UPDATE components SET model_type=? WHERE id=?',(_new_model.strip(),cid));con.commit();st.rerun()
   st.write(f'**Bewertung:** {stat}')
   if 'helios' in str(m).lower() and 'sb125a' in ''.join(c for c in str(a or p).lower() if c.isalnum()):
    st.caption('Helios SB 125 A – automatische Herstellersuche im bestehenden Produktbereich starten')
    if st.button('Helios-Dokumente im bestehenden Suchbereich prüfen',key=f'helios_extract_{cid}'):
     st.info('Helios blockiert den direkten Seitenabruf (HTTP 403). Bitte die vorhandene Herstellersuche und Offline-PDFs verwenden.')
    for _pdf in st.session_state.get(f'helios_pdfs_{cid}',[]):st.link_button('PDF-Kandidat prüfen',_pdf)
   if 'helios' in str(m).lower() and 'sb125a' in ''.join(c for c in str(a or p).lower() if c.isalnum()):
    st.caption('Offizielle Helios-Dokumentensuche – PDF-Kandidaten prüfen')
    if st.button('HELIOS-Dokumente mit Versionsprüfung suchen',key=f'helios_index_{cid}'):
      _hits,_warnings=helios_search_pdf_candidates('SB 125 A')
      st.session_state[f'universal-hits-{cid}']=_hits
      st.session_state[f'universal-source-{cid}']='HELIOS-Produktseite'
      if _hits:st.success(f'{len(_hits)} verifizierte HELIOS-PDFs gefunden. Bitte unten prüfen und für die Offline-Speicherung auswählen.')
      else:st.warning('Kein HELIOS-PDF abrufbar. Details unter Hinweise zur Suche.')
      if _warnings:st.caption('Hinweise zur Suche: '+', '.join(_warnings[:3]))
    st.link_button('Helios PDF-Dokumente finden','https://www.google.com/search?q=site%3Aheliosventilatoren.de+SB+125+A+filetype%3Apdf')
   if 'danfoss' in str(m).lower() and 'eclcomfort310' in ''.join(c for c in str(a or p).lower() if c.isalnum()):
    st.caption('Offizielle Danfoss-Dokumentensuche – Ausführung prüfen')
    st.link_button('Danfoss PDF-Dokumente finden','https://www.google.com/search?q=site%3Aassets.danfoss.com+ECL+Comfort+310+filetype%3Apdf')
   _known_products={('helios','sb125a'):'https://www.heliosventilatoren.de/de/produkte/boxventilatoren/silentbox/sb-125-a-09506',('danfoss','eclcomfort310'):'https://www.danfoss.com/de-de/products/dhs/electronic-controls/electronic-controllers-and-application-keys/ecl-comfort-controllers/'}
   _norm=lambda x:''.join(c for c in str(x or '').lower() if c.isalnum())
   _model=_norm(a)+' '+_norm(p)
   _url=next((url for (maker,model),url in _known_products.items() if maker in _norm(m) and model in _model),None)
   if _url:
    st.caption('Automatisch erkannte offizielle Herstellerseite · Produktausführung prüfen')
    st.link_button('Erkannte Herstellerseite öffnen',_url)
   if any(x in str(m).lower() for x in ('trox','helios','danfoss')):
    import urllib.parse
    _domain=next((d for k,d in (('trox','trox.de'),('helios','heliosventilatoren.de'),('danfoss','danfoss.com')) if k in str(m).lower()),None)
    _term='site:'+_domain+' '+str(m)+' '+str(a or p)
    st.link_button('Offizielle Produktseite suchen','https://www.google.com/search?q='+urllib.parse.quote_plus(_term))
    st.link_button('Hersteller-PDFs suchen','https://www.google.com/search?q='+urllib.parse.quote_plus(_term+' Datenblatt Montageanleitung PDF'))
   _linked_uploads=project_uploads_for_component(con,project,cid)
   if _linked_uploads:
    st.markdown('**Zugeordnete individuelle Projektunterlagen**')
    for _uid,_filename,_path,_digest,_score,_confirmed in _linked_uploads:
     _a,_b=st.columns([4,1])
     _a.write(_filename+' · '+str(_score)+' % · '+('Zuordnung bestätigt' if _confirmed else ('Produkt eindeutig zugeordnet – Prüfung offen' if _score>=90 else 'Produktfamilie/Zuordnung prüfen')))
     with open(_path,'rb') as _f:_b.download_button('Datei öffnen',_f.read(),file_name=_filename,key=f'linked_upload_{cid}_{_uid}')
   manufacturer_product_name,name_confirmed=con.execute('SELECT manufacturer_product_name,product_name_confirmed FROM components WHERE id=?',(cid,)).fetchone()
   if is_rockwool_conlit(m,p):
    st.markdown('**Herstellerbezeichnung prüfen**')
    if name_confirmed and manufacturer_product_name==CONLIT_OFFICIAL_NAME:
     st.success(f'Bestätigte Herstellerbezeichnung: {CONLIT_OFFICIAL_NAME}')
     st.caption(f'Ursprünglicher Excel-Eintrag bleibt erhalten: „{p}“. Für Suche und Dokumentzuordnung wird die bestätigte Herstellerbezeichnung verwendet.')
     if st.button('↩️ Herstellerbezeichnung zurücksetzen',key=f'conlit-name-reset-{cid}'):
      con.execute('UPDATE components SET manufacturer_product_name="", product_name_confirmed=0, docs_searched=0 WHERE id=?',(cid,)); con.commit(); st.rerun()
    else:
     st.warning(f'Der Excel-Eintrag „{p}“ ist nicht die aktuelle vollständige Herstellerbezeichnung.')
     st.write(f'**Meinst du {CONLIT_OFFICIAL_NAME}?**')
     c_yes,c_no=st.columns(2)
     if c_yes.button('✓ Ja, diese Bezeichnung übernehmen',key=f'conlit-name-yes-{cid}',type='primary'):
      con.execute('UPDATE components SET manufacturer_product_name=?, product_name_confirmed=1, confidence=100, status=? WHERE id=?',(CONLIT_OFFICIAL_NAME,'Herstellerbezeichnung bestätigt',cid)); con.commit(); st.rerun()
     if c_no.button('Nein / anderes Produkt',key=f'conlit-name-no-{cid}'):
      con.execute('UPDATE components SET manufacturer_product_name="", product_name_confirmed=0 WHERE id=?',(cid,)); con.commit(); st.info('Bitte Produktbezeichnung bzw. Artikelnummer im Bestand klären. Die automatische Conlit-Zuordnung wird nicht als bestätigt behandelt.')
   if is_geberit_mapress_therm(m,p) and not a:
    st.markdown('**Geberit Mapress Therm · verbaute Systemkomponenten**')
    st.warning('„Mapress Therm“ ist ein System. In einem Projekt können mehrere Komponenten gleichzeitig verbaut sein. Bitte alle tatsächlich vorhandenen Dokumentgruppen markieren.')
    choices=['Systemrohr CrTi']+list(MAPRESS_THERM_FITTINGS)
    saved_sel=get_component_selections(con,cid)
    selected=st.multiselect('Welche Komponenten sind im Projekt verbaut?',choices,default=[x for x in saved_sel if x in choices],key=f'mapress-multi-{cid}')
    if selected:
     st.success('Ausgewählt: '+', '.join(selected))
     st.caption('Dimensionen werden weiterhin nur getrennt, wenn sie andere relevante Unterlagen benötigen. Für die Montage bleibt d108 als fachlicher Prüffall gekennzeichnet.')
     if set(selected)!=set(saved_sel):
      if st.button('✓ Auswahl im Projekt speichern',key=f'mapress-save-{cid}',type='primary'):
       save_component_selections(con,cid,selected); con.execute('UPDATE components SET docs_searched=0 WHERE id=?',(cid,)); con.commit(); st.rerun()
     else:
      st.info('Diese Mehrfachauswahl ist im Projekt gespeichert.')
      if st.button('🔎 Dokumente für alle ausgewählten Mapress-Komponenten suchen',key=f'mapress-docs-multi-{cid}',type='primary'):
       source,docs=mapress_selection_docs(selected); st.session_state[f'd-{cid}']=docs; st.session_state[f'q-{cid}']=source; persist_search_docs(con,cid,docs); st.rerun()
    else:
     st.caption('Noch keine Mapress-Systemkomponente ausgewählt. Beispiel: Systemrohr CrTi + Muffe können gleichzeitig markiert werden.')
     if saved_sel and st.button('Leere Auswahl speichern',key=f'mapress-clear-{cid}'):
      save_component_selections(con,cid,[]); con.execute('UPDATE components SET docs_searched=0 WHERE id=?',(cid,)); con.commit(); st.rerun()
    st.caption('Grundsatz: Mehrere tatsächlich verbaute Systemkomponenten dürfen gleichzeitig ausgewählt werden. Reine Dimensionsvarianten erzeugen nur bei dokumentrelevanten Unterschieden eigene Gruppen.')
   if is_geberit_verified(m,a):
    cfg=GEBERIT_VERIFIED_PRODUCTS[clean(a)]
    st.success(f"Geberit-Artikel exakt erkannt: {a} — {cfg['name']} · {cfg['details']}")
    if st.button('🔎 Geberit-Dokumente für exakten Artikel suchen',key=f'geberit-search-{cid}',type='primary'):
     source,docs=find_geberit_docs(a); st.session_state[f'd-{cid}']=docs; st.session_state[f'q-{cid}']=source; persist_search_docs(con,cid,docs)
     st.rerun()
   if is_grohe_eurosmart_ce(m,p):
    st.markdown('**GROHE-Variantenauflösung**')
    if a in GROHE_VARIANTS:
     st.success(f'Variante bestätigt: {grohe_variant_label(a)}')
     st.caption('Die konkrete Artikelnummer ist dem Bauteil zugeordnet. Die Dokumentensuche wird ausschließlich über diese Artikelnummer gestartet.')
     if st.button('🔎 GROHE-Dokumente für bestätigte Variante suchen',key=f'grohe-search-{cid}',type='primary'):
      try:
       with st.spinner(f'Offizielle GROHE-Produktseite für {a} wird ausgewertet …'): source,docs=find_grohe_docs(a)
       st.session_state[f'd-{cid}']=docs; st.session_state[f'q-{cid}']=source; persist_search_docs(con,cid,docs)
       st.rerun()
       if docs: st.success(f'{len(docs)} variantenspezifische Dokumente gefunden.')
       else: st.warning('Auf der offiziellen GROHE-Produktseite wurden noch keine eindeutig klassifizierbaren Dokumentlinks erkannt.')
      except Exception as e: st.error(str(e))
     if st.button('↩️ Variantenbestätigung zurücksetzen',key=f'grohe-reset-{cid}'):
      con.execute('UPDATE components SET article_no=?, confidence=?, status=? WHERE id=?',('',85,'Bestätigung empfohlen',cid)); con.commit(); st.rerun()
    else:
     st.warning('„Eurosmart CE“ ist eine Produktfamilie. Bitte die tatsächlich verbaute Variante bestätigen, bevor Dokumente zugeordnet werden.')
     options=['Bitte Variante auswählen …']+list(GROHE_VARIANTS)
     choice=st.selectbox('Variante / Artikelnummer',options,key=f'grohe-var-{cid}',format_func=lambda x: x if x.startswith('Bitte') else grohe_variant_label(x))
     if choice!='Bitte Variante auswählen …':
      st.info(GROHE_VARIANTS[choice]['details'])
      if choice=='36332000':
       st.link_button('Offizielle GROHE-Produktseite öffnen','https://www.grohe.de/de_de/eurosmart-ce-infrarot-elektronik-waschtisch-wandarmatur-mit-mischeinrichtung-und-thermostat-36332000.html')
      else:
       st.link_button('Artikelnummer bei GROHE suchen','https://www.google.com/search?q='+urllib.parse.quote(f'site:grohe.de Eurosmart CE {choice}'))
      if st.button('✓ Diese Variante bestätigen',key=f'grohe-confirm-{cid}',type='primary'):
       con.execute('UPDATE components SET article_no=?, confidence=?, status=? WHERE id=?',(choice,100,'Variante bestätigt',cid)); con.commit(); st.rerun()
    if a not in GROHE_VARIANTS: st.caption('Dokumente werden bewusst noch nicht geladen, solange keine konkrete GROHE-Variante bestätigt ist.')
   conlit_name_ok=(not is_rockwool_conlit(m,p)) or bool(name_confirmed and manufacturer_product_name==CONLIT_OFFICIAL_NAME)
   _search_product=search_product_for_component(m,p,a)
   if 'trox' in clean(m).lower():
    _manual=st.selectbox('TROX-Modell für Dokumentensuche', ['Automatisch erkennen','FKRS-EU','FK2-EU','TVE'],key=f'trox-search-model-{cid}',help='Wähle das tatsächlich verbaute Modell. Die Excel-Daten werden nicht verändert.')
    if _manual!='Automatisch erkennen':
     _search_product=_manual
     st.caption('Manuelle Modellauswahl nur für diese Dokumentensuche; keine automatische Dokumentenfreigabe.')
    elif product_key(m,_search_product) not in PRODUCTS:
     st.warning('TROX-Modell nicht eindeutig erkannt. Bitte oben das tatsächlich verbaute Modell auswählen.')
   auto=(product_key(m,_search_product) in PRODUCTS and conlit_name_ok) or (is_grohe_eurosmart_ce(m,p) and a in GROHE_VARIANTS) or is_geberit_verified(m,a) or is_geberit_mapress_therm(m,p)
   if not auto:
    st.markdown('**Universelle Dokumentensuche – Pilotbetrieb**')
    st.caption('Für alle weiteren Hersteller: Zuerst Produktseite und Dokumente automatisch suchen anklicken. Eine manuelle Herstelleradresse ist nur als Alternative nötig. PDF-Kandidaten bleiben prüfpflichtig.')
    _official=st.text_input('HTTPS-Adresse der offiziellen Hersteller-Produktseite',key=f'universal-url-{cid}',placeholder='https://www.hersteller.de/produkt/...')
    if st.button('Mehrstufige Dokumentensuche starten',key=f'universal-auto-{cid}',type='primary'):
     with st.spinner('Hersteller- und geprüfte Produktquellen werden durchsucht …'):
      _source,_hits,_stages=multistage_document_candidates(m,p,a,_official)
     st.session_state[f'universal-hits-{cid}']=_hits
     st.session_state[f'universal-source-{cid}']=_source
     st.session_state[f'universal-stages-{cid}']=_stages
     if _hits:st.success(str(len(_hits))+' Dokumentkandidat(en) gefunden. Fachliche Freigabe offen.')
     else:st.warning('Keine passenden PDF-Kandidaten gefunden. Suchprotokoll prüfen.')
    if st.session_state.get(f'universal-stages-{cid}'):
     with st.expander('Suchprotokoll',expanded=False):
      for _step in st.session_state[f'universal-stages-{cid}']:st.write(_step)
    with st.expander("Herstellerübergreifende Suchmuster für dieses Produkt",expanded=False):
     st.caption("Suchbegriffe für Typ, Artikelnummer und Dokumentarten. Treffer sind nicht automatisch freigegeben.")
     st.dataframe(pd.DataFrame(universal_product_search_patterns(m,p,a)),hide_index=True,width="stretch")
    if st.button('Dokumentkandidaten auf Herstellerseite suchen',key=f'universal-search-{cid}'):
     try:
      _source,_hits=universal_docs_from_official_page(m,p,a,_official)
      st.session_state[f'universal-hits-{cid}']=_hits
      st.session_state[f'universal-source-{cid}']=_source
     except Exception as _error:st.error(str(_error))
    _hits=st.session_state.get(f'universal-hits-{cid}',[])
    if not _hits and st.session_state.get(f'universal-source-{cid}'):
     st.info('Keine geeigneten direkten PDF-Links gefunden. Der Hersteller kann Downloads über Skripte oder externe Dokumentenportale bereitstellen.')
    if _hits:
     st.warning(f'{len(_hits)} Dokumentkandidaten gefunden. Keine automatische Zuordnung oder Freigabe.')
     st.dataframe(pd.DataFrame(_hits)[['Kategorie','Titel','Treffer %','URL']],hide_index=True,width='stretch')
     st.caption('PDF-Kandidaten sind nicht fachlich freigegeben. Bitte Dokument und Ausführung vor dem Speichern kontrollieren.')
     _selected=st.multiselect('PDF-Kandidaten für Offline-Speicherung auswählen',options=list(range(len(_hits))),format_func=lambda i: _hits[i]['Kategorie']+' · '+_hits[i]['Titel'],key=f'universal-select-{cid}')
     if st.button('Ausgewählte echte PDFs offline speichern',key=f'universal-download-{cid}',disabled=not _selected):
      _success=[];_failed=[]
      for _i in _selected:
       try:
        _path,_size=save_universal_pdf_candidate(con,cid,project,m,p,_hits[_i])
        _success.append(_hits[_i]['Titel'])
       except Exception as _exc:_failed.append(_hits[_i]['Titel']+': '+str(_exc))
      if _success:st.success(str(len(_success))+' echte PDF-Datei(en) offline gespeichert. Fachliche Freigabe weiterhin offen.')
      for _error in _failed:st.error(_error)
     st.caption('PDF-Kandidaten von einer modellbestätigten Produktseite. Keine fachliche Freigabe; Treffer manuell prüfen.')
   if 'trox' in clean(m).lower() and _search_product=='FKRS-EU':
    st.markdown('**Ausführungsprüfung – FKRS-EU**')
    st.caption('Gemeinsame Herstellerunterlagen können für die Produktfamilie genutzt werden. Die Eignung für die konkret verbaute Ausführung muss separat nachgewiesen werden.')
    _variant=clean(a).upper()
    _overflow=('AA' in _variant.split('/') or 'Z43RM' in _variant or 'ÜBERSTRÖM' in clean(p).upper())
    st.write(f'Verbaute Ausführung laut Excel: **{a or p}**')
    if _overflow:
     st.warning('Überström-Ausführung erkannt: Überströmfunktion, Zubehör AA/Z43RM, Einbausituation und zugehörige Verwendbarkeitsnachweise fachlich prüfen.')
    else:
     st.info('Standardausführung: Einbausituation, Antrieb/Zubehör und Gültigkeitsbereich von DoP, Montageanleitung und Nachweisen prüfen.')
    st.caption('Status: Ausführungsnachweise fachlich offen. Heruntergeladene PDFs gelten nicht automatisch als freigegeben.')
   if 'trox' in clean(m).lower() and _search_product=='FKRS-EU':
    con.execute('CREATE TABLE IF NOT EXISTS variant_checks(component_id INTEGER PRIMARY KEY, model TEXT, installation TEXT, overflow TEXT, atex TEXT, special TEXT, evidence TEXT, note TEXT, updated_at TEXT)')
    _saved=con.execute('SELECT model,installation,overflow,atex,special,evidence,note FROM variant_checks WHERE component_id=?',(cid,)).fetchone()
    _docs=con.execute('SELECT doc_type,title FROM documents WHERE component_id=?',(cid,)).fetchall()
    _has_atex=any('ATEX' in (str(k)+' '+str(t)).upper() for k,t in _docs)
    _has_special=any('SONDERANWENDUNG' in str(k).upper() or '_SV_IOM_' in str(t).upper() for k,t in _docs)
    _variant=clean(a).upper()
    _has_overflow=('AA' in _variant.split('/') or 'Z43RM' in _variant or 'ÜBERSTRÖM' in clean(p).upper())
    _opts=['Noch nicht geprüft','Ja','Nein','Unklar']
    _pick=lambda val: _opts.index(val) if val in _opts else 0
    if _has_atex or _has_special or _has_overflow:
     st.markdown('**Dokumentbezogene Projektprüfungen – FKRS-EU**')
     st.caption('Nur für gefundene Zusatzdokumente oder die erkannte Sonderausführung. Standarddokumente bleiben unverändert.')
     with st.form(key=f'fkrs-check-{cid}'):
      if _has_atex:
       st.write('**ATEX-Dokumente:** '+', '.join(str(t) for k,t in _docs if 'ATEX' in (str(k)+' '+str(t)).upper())[:300])
       _atex=st.selectbox('ATEX-Anwendung für diese Komponente vorhanden?',_opts,index=_pick(_saved[3] if _saved else None))
      else:
       _atex=_saved[3] if _saved else 'Noch nicht geprüft'
      if _has_special:
       st.write('**Montage-Sonderanwendung:** '+', '.join(str(t) for k,t in _docs if 'SONDERANWENDUNG' in str(k).upper() or '_SV_IOM_' in str(t).upper())[:300])
       _special=st.selectbox('Sondermontage bei dieser Komponente vorhanden?',_opts,index=_pick(_saved[4] if _saved else None))
      else:
       _special=_saved[4] if _saved else 'Noch nicht geprüft'
      if _has_overflow:
       st.warning('Ausführung AA/Z43RM: Überströmfunktion und Zubehör benötigen eine gesonderte Eignungsprüfung.')
       _overflow=st.selectbox('Überströmfunktion und Zubehör für diese Ausführung nachgewiesen?',_opts,index=_pick(_saved[2] if _saved else None))
      else:
       _overflow=_saved[2] if _saved else 'Noch nicht geprüft'
      _note=st.text_area('Prüfvermerk / Nachweisquelle (optional)',value=_saved[6] if _saved and _saved[6] else '',key=f'fkrs-note-{cid}')
      _save=st.form_submit_button('Dokumentenprüfung speichern')
     if _save:
      con.execute("INSERT OR REPLACE INTO variant_checks(component_id,model,installation,overflow,atex,special,evidence,note,updated_at) VALUES(?,?,?,?,?,?,?,?,datetime('now'))",(cid,clean(a),_saved[1] if _saved else 'Noch nicht geprüft',_overflow,_atex,_special,_saved[5] if _saved else 'Noch nicht geprüft',_note))
      con.commit()
      st.success('Projektbezogene Entscheidungen gespeichert – keine automatische Freigabe.')
     _current=con.execute('SELECT overflow,atex,special FROM variant_checks WHERE component_id=?',(cid,)).fetchone()
     if _current:
      if _has_atex and _current[1]=='Nein': st.info('ATEX: Für dieses Projekt als nicht erforderlich angegeben; Herstellerunterlagen bleiben erhalten.')
      if _has_special and _current[2]=='Nein': st.info('Sondermontage: Für dieses Projekt als nicht erforderlich angegeben.')
      if _has_overflow and _current[0]!='Ja': st.warning('Überström-Ausführung: Eignungsnachweis weiterhin offen.')
     else:
      st.caption('Zusatzprüfungen noch nicht beantwortet.')
    else:
     st.caption('Keine zusätzlichen dokumentbezogenen Projektfragen erforderlich.')
   if auto:
    if not is_grohe_eurosmart_ce(m,p) and not is_geberit_verified(m,a) and not is_geberit_mapress_therm(m,p) and st.button(f'🔎 {m}-Dokumente automatisch suchen',key=f's-{cid}',type='primary'):
     try:
      with st.spinner(f'Offizielle {m}-Produktseite wird ausgewertet …'): source,docs=find_docs(m,_search_product)
      st.session_state[f'd-{cid}']=docs; st.session_state[f'q-{cid}']=source; persist_search_docs(con,cid,docs)
      st.rerun()
      if docs:
       st.success(f'{len(docs)} mögliche Dokumente gefunden.')
      else:
       st.warning('Keine Dokumentlinks erkannt.')
     except Exception as e:st.error(str(e))
    docs=st.session_state.get(f'd-{cid}',[]); source=st.session_state.get(f'q-{cid}')
    if source: st.caption(f'Geprüfte Herstellerseite: {source} · erkannte Links: {len(docs)}')
    if docs:
     rel=[d for d in docs if d['Relevant']]
     recommended_diag=[d for d in rel if d['Priorität']=='Empfohlen']
     check_diag=[d for d in rel if d['Priorität'] in ['Anwendungsfall prüfen','Optional / Ausführung prüfen']]
     optional_diag=[d for d in rel if d['Priorität']=='Optional']
     st.caption(f"Diagnose: {len(docs)} akzeptierte Herstellerlinks · {len(rel)} produktrelevant · {len(recommended_diag)} empfohlen · {len(check_diag)} prüfen · {len(optional_diag)} optional")
     st.markdown(f'**Relevante Produktdokumente: {len(rel)} von {len(docs)} Treffern**')
     if rel:
      rdf=pd.DataFrame(rel); st.dataframe(rdf[['Kategorie','Priorität','Titel','Resolver','Treffer %','URL']],width='stretch',hide_index=True)
      recommended=[d for d in rel if d['Priorität']=='Empfohlen']
      downloadable_recommended=[d for d in recommended if d.get('Downloadbar',True)]
      online_evidence=[d for d in recommended if not d.get('Downloadbar',True)]
      st.write(f'**Standardmappe:** {len(recommended)} Dokument(e) als „Empfohlen“ markiert · {len(downloadable_recommended)} als Offline-PDF · {len(online_evidence)} als verifizierter Online-Nachweis.')
      if product_key(m,p)[1]=='CONLIT U': st.info('Conlit 150 U: produktbezogener Verwendbarkeitsnachweis laut ROCKWOOL: abP P-NDS04-417. Der generische DoP-Link wird deshalb nicht als empfohlenes Produktdokument gewertet.')
      for ev in online_evidence:
       if ev.get('Nachweis URL'):
        st.info(f"{ev['Titel']}: verifizierter Online-Nachweis (kein Offline-PDF-Download wird vorgetäuscht).")
        st.link_button(f"Nachweis öffnen: {ev['Titel']}",ev['Nachweis URL'],key=f"ev-{cid}-{hashlib.sha1(ev['Titel'].encode()).hexdigest()[:8]}")
      c1,c2=st.columns(2)
      if c1.button('⬇️ Empfohlene PDFs offline speichern',key=f'dlr-{cid}',type='primary',disabled=not downloadable_recommended):
       todo=downloadable_recommended; ok=0; errs=[]
       for d in todo:
        try:
         path,size,resolved_url=download(project,m,p,d); con.execute('DELETE FROM documents WHERE component_id=? AND source_url=? AND title=?',(cid,d['URL'],d['Titel'])); con.execute('INSERT INTO documents(component_id,doc_type,title,source_url,verified,confidence,source_page,local_path,download_status,priority) VALUES(?,?,?,?,?,?,?,?,?,?)',(cid,d['Kategorie'],d['Titel'],d['URL'],0,d['Treffer %'],d['Quellseite'],path,f'Offline · {size/1024/1024:.1f} MB',d['Priorität'])); ok+=1
        except Exception as e:errs.append(f"{d['Titel']}: {e}")
       con.commit(); st.session_state[f'download-report-{cid}']={'ok':ok,'errs':errs,'kind':'empfohlen'}; st.rerun()
      if c2.button('⬇️ Alle relevanten PDFs offline speichern',key=f'dla-{cid}',disabled=not rel):
       ok=0; errs=[]
       for d in [x for x in rel if x.get('Downloadbar',True)]:
        try:
         path,size,resolved_url=download(project,m,p,d); con.execute('DELETE FROM documents WHERE component_id=? AND source_url=? AND title=?',(cid,d['URL'],d['Titel'])); con.execute('INSERT INTO documents(component_id,doc_type,title,source_url,verified,confidence,source_page,local_path,download_status,priority) VALUES(?,?,?,?,?,?,?,?,?,?)',(cid,d['Kategorie'],d['Titel'],d['URL'],0,d['Treffer %'],d['Quellseite'],path,f'Offline · {size/1024/1024:.1f} MB',d['Priorität'])); ok+=1
        except Exception as e:errs.append(f"{d['Titel']}: {e}")
       con.commit(); st.session_state[f'download-report-{cid}']={'ok':ok,'errs':errs,'kind':'alle relevanten'}; st.rerun()
     with st.expander('Alle erkannten Herstellerlinks'): st.dataframe(pd.DataFrame(docs)[['Kategorie','Priorität','Titel','Resolver','Treffer %','URL']],width='stretch',hide_index=True)
   elif not is_grohe_eurosmart_ce(m,p):
    if 'kermi' in str(m).lower() and 'basic' in str(p+' '+a).lower():
                    if st.button('KERMI-Dokumente direkt beim Hersteller prüfen',key=f'kermi_direct_{cid}'):
                     try:
                      _khits=kermi_basic_official_documents()
                      st.session_state[f'universal-hits-{cid}']=_khits
                      st.session_state[f'universal-source-{cid}']='KERMI Basic Herstellerseite'
                      if _khits:st.success(str(len(_khits))+' verifizierte KERMI-PDF-Kandidaten gefunden. Fachliche Freigabe offen.')
                      else:st.warning('Keine PDF verfügbar: KERMI-Downloadcenter und Sekundärquelle aktuell nicht abrufbar.')
                     except Exception as exc:
                      st.warning('KERMI-Suche derzeit nicht erfolgreich: '+str(exc)[:160])
                    _kermi_hits=st.session_state.get(f'universal-hits-{cid}',[])
                    if _kermi_hits:
                     st.markdown('**Gefundene KERMI-Unterlagen – Offline-Speicherung**')
                     for _k in _kermi_hits: st.write('PDF-Kandidat: '+str(_k.get('Titel','Unbenannt'))); st.caption('Quelle: '+document_source_policy(str(_k.get('URL','')))[0]+' · Fachliche Freigabe offen')
                     if st.button('KERMI-PDF jetzt offline speichern',key=f'kermi_save_{cid}',type='primary'):
                      try:
                       _saved=[]
                       for _k in _kermi_hits:
                        _path,_size=save_universal_pdf_candidate(con,cid,project,m,p,_k)
                        _saved.append(_k.get('Titel','PDF'))
                       con.commit()
                       st.success(str(len(_saved))+' KERMI-PDF(s) offline gespeichert. Fachliche Freigabe offen.')
                      except Exception as _exc: st.error('Offline-Speicherung fehlgeschlagen: '+str(_exc))
                    st.caption('Die genaue Basic-E-Ausführung vor fachlicher Freigabe prüfen.')
                   # st.info('Für dieses Produkt die universelle Dokumentensuche oben verwenden. Klicke auf Produktseite und Dokumente automatisch suchen. Keine Weiterleitung zu Google erforderlich.')
   report=st.session_state.get(f'download-report-{cid}')
   if report:
    st.success(f"{report['ok']} PDF(s) erfolgreich offline gespeichert.")
    if report['errs']:
     st.warning(f"{len(report['errs'])} Download(s) fehlgeschlagen.")
     for msg in report['errs']: st.caption(msg)
   for _fkcode in ['fk2_atex','fk2_special_mounting']:
    _fkr=st.session_state.get(f'fk2-group-report-{cid}-{_fkcode}')
    if _fkr:
     if _fkr['ok']==_fkr['total'] and not _fkr['errs']: st.success(f"{_fkr['ok']} von {_fkr['total']} benötigten {FK2_APPLICATION_GROUPS[_fkcode]}-Dokumenten offline gespeichert/verifiziert.")
     else:
      st.warning(f"{_fkr['ok']} von {_fkr['total']} benötigten {FK2_APPLICATION_GROUPS[_fkcode]}-Dokumenten konnten offline gespeichert/verifiziert werden.")
      for _msg in _fkr['errs']: st.caption(_msg)
   conlit_report=st.session_state.get(f'conlit-proof-report-{cid}')
   if conlit_report:
    if conlit_report['ok']==conlit_report['total'] and not conlit_report['errs']: st.success(f"{conlit_report['ok']} Conlit-Nachweis(e) automatisch zugeordnet und offline gespeichert.")
    else:
     st.warning(f"{conlit_report['ok']} von {conlit_report['total']} Conlit-Nachweisen konnten automatisch offline gespeichert werden.")
     for msg in conlit_report['errs']: st.caption(msg)
   saved=con.execute('SELECT id,doc_type,title,source_url,confidence,local_path,download_status,priority,project_confirmed,source_page,project_decision,project_decision_note FROM documents WHERE component_id=? ORDER BY priority,doc_type,title',(cid,)).fetchall()
   if saved and is_trox_fk2(m,p):
    fk2_saved_groups=get_application_groups(con,cid)
    if 'fk2_standard' in fk2_saved_groups:
     selected_extra=[x for x in fk2_saved_groups if x in ['fk2_atex','fk2_special_mounting']]
     save_fk2_application(con,cid,selected_extra,saved)
     saved=con.execute('SELECT id,doc_type,title,source_url,confidence,local_path,download_status,priority,project_confirmed,source_page,project_decision,project_decision_note FROM documents WHERE component_id=? ORDER BY priority,doc_type,title',(cid,)).fetchall()
   if saved:
    st.markdown('**Dokumentenmappe**')
    for docid,dtype,title,url,dconf,path,dstatus,prio,confirmed,source_page,decision,decision_note in saved:
     exists=bool(path and os.path.exists(path)); c1,c2,c3=st.columns([4,1,1]); c1.write(f'**{dtype}** · {title}'); c1.caption(prio or ''); c2.write('✅ Offline' if exists else ('🌐 Online' if dstatus=='Online-Nachweis' else '⚠️ Fundstelle'))
     if exists:
      with open(path,'rb') as fh:c3.download_button('PDF öffnen',data=fh.read(),file_name=os.path.basename(path),mime='application/pdf',key=f'p-{cid}-{docid}')
     elif url:c3.link_button('Quelle',url)
    if is_trox_fk2(m,p):
     st.markdown('### 🧭 FK2-EU · Anwendung festlegen')
     st.caption('Standardunterlagen gelten immer. Zusätzliche Auswahlmöglichkeiten erscheinen nur für Anwendungen, die andere Dokumentgruppen benötigen.')
     saved_groups=get_application_groups(con,cid)
     selected_labels=[]
     if 'fk2_atex' in saved_groups: selected_labels.append(FK2_APPLICATION_GROUPS['fk2_atex'])
     if 'fk2_special_mounting' in saved_groups: selected_labels.append(FK2_APPLICATION_GROUPS['fk2_special_mounting'])
     options=[FK2_APPLICATION_GROUPS['fk2_atex'],FK2_APPLICATION_GROUPS['fk2_special_mounting']]
     choices=st.multiselect('Welche zusätzlichen Sonderanwendungen kommen in diesem Projekt vor?',options,default=selected_labels,key=f'fk2-app-{cid}')
     st.write('**Standardanwendung / Standarddokumentation ist immer die Basis.**')
     if not choices: st.info('Keine zusätzliche Sonderanwendung ausgewählt. ATEX- und Sondermontage-Unterlagen werden für dieses Projekt nicht als Pflichtunterlagen gewertet.')
     else:
      if FK2_APPLICATION_GROUPS['fk2_atex'] in choices: st.write('• ATEX → die zusammengehörige ATEX-Dokumentgruppe wird benötigt (nicht vier getrennte Projektentscheidungen).')
      if FK2_APPLICATION_GROUPS['fk2_special_mounting'] in choices: st.write('• Montage-Sonderanwendung → die zusätzliche Sondermontage-Dokumentgruppe wird benötigt.')
     if st.button('FK2-EU Anwendung speichern',key=f'fk2-app-save-{cid}',type='primary'):
      codes=[]
      if FK2_APPLICATION_GROUPS['fk2_atex'] in choices: codes.append('fk2_atex')
      if FK2_APPLICATION_GROUPS['fk2_special_mounting'] in choices: codes.append('fk2_special_mounting')
      save_fk2_application(con,cid,codes,saved); st.rerun()
     for code in ['fk2_atex','fk2_special_mounting']:
      if code in saved_groups:
       group_rows=[r for r in saved if fk2_check_group(r[1])==code]
       complete=fk2_group_complete(saved,code)
       if complete: st.success(f"{FK2_APPLICATION_GROUPS[code]}: benötigte Dokumentgruppe vorhanden.")
       else:
        st.warning(f"{FK2_APPLICATION_GROUPS[code]}: ausgewählt, aber die benötigten PDF-Unterlagen sind noch nicht vollständig offline gespeichert/verifiziert.")
        required_rows=fk2_required_group_rows(saved,code)
        if required_rows:
         st.caption('Benötigte aktuelle Dokumente: ' + ' · '.join(r[2] for r in required_rows))
         if st.button(f'⬇️ {FK2_APPLICATION_GROUPS[code]} gezielt offline speichern',key=f'fk2-group-dl-{cid}-{code}'):
          ok=0; errs=[]
          for rr in required_rows:
           rdocid,rdtype,rtitle,rurl,rdconf,rpath,rdstatus,rprio,rconfirmed,rsource,rdecision,rnote=rr
           if (rpath and os.path.exists(rpath)) or rdstatus=='Online-Nachweis':
            ok+=1; continue
           d={'Kategorie':rdtype,'Titel':rtitle,'URL':rurl,'Treffer %':rdconf,'Quellseite':rsource,'Priorität':rprio}
           try:
            path,size,resolved_url=download(project,m,p,d)
            con.execute('UPDATE documents SET local_path=?,download_status=?,verified=1 WHERE id=?',(path,f'Offline · {size/1024/1024:.1f} MB',rdocid)); ok+=1
           except Exception as e: errs.append(f'{rtitle}: {e}')
          con.commit()
          refreshed=con.execute('SELECT id,doc_type,title,source_url,confidence,local_path,download_status,priority,project_confirmed,source_page,project_decision,project_decision_note FROM documents WHERE component_id=? ORDER BY priority,doc_type,title',(cid,)).fetchall()
          selected_now=[x for x in get_application_groups(con,cid) if x in ['fk2_atex','fk2_special_mounting']]
          save_fk2_application(con,cid,selected_now,refreshed)
          st.session_state[f'fk2-group-report-{cid}-{code}']={'ok':ok,'total':len(required_rows),'errs':errs}
          st.rerun()
        else:
         st.error('Für diese Zusatzgruppe wurde noch kein passender Hersteller-Nachweis erkannt. Bitte Herstellersuche erneut ausführen.')
    open_checks=[d for d in saved if d[7] in ['Anwendungsfall prüfen','Optional / Ausführung prüfen'] and not d[8] and not (is_trox_fk2(m,p) and fk2_check_group(d[1]))]
    confirmed_checks=[d for d in saved if d[7] in ['Anwendungsfall prüfen','Optional / Ausführung prüfen'] and d[8] and not (is_trox_fk2(m,p) and fk2_check_group(d[1]))]
    if open_checks:
     st.markdown('### ⚠️ Offene Projektprüfungen')
     st.caption('Diese Punkte benötigen eine fachliche Entscheidung für genau dieses Projekt. Die Herstellerquelle bleibt davon unverändert.')
     for docid,dtype,title,url,dconf,path,dstatus,prio,confirmed,source_page,decision,decision_note in open_checks:
      st.warning(f'**{dtype}: {title}**')
      if source_page: st.caption(source_page)
      is_mapress_install=('mapress therm' in clean(p).lower() and 'installation / verarbeitung' in clean(title).lower())
      is_rockwool800_proof=('rockwool' in clean(m).lower() and product_key(m,p)[1]=='800' and dtype=='Zulassung / Prüfzeugnis' and 'anwendbarkeitsnachweise' in clean(title).lower())
      is_conlit_proof=(is_rockwool_conlit(m,p) and dtype=='Zulassung / Prüfzeugnis' and 'anwendbarkeitsnachweise' in clean(title).lower())
      if is_mapress_install:
       st.write('**Geführte Prüfung:** Geberit weist für d108 eine abweichende Verarbeitung aus. Welche Dimensionen sind in diesem Projekt verbaut?')
       options=['Noch nicht bekannt','Nur d12–d88,9','d108 ist ebenfalls verbaut']
       prior={'mapress_unknown':'Noch nicht bekannt','mapress_no_d108':'Nur d12–d88,9','mapress_d108':'d108 ist ebenfalls verbaut'}.get(decision,'Noch nicht bekannt')
       choice=st.radio('Dimensionen im Projekt',options,index=options.index(prior),key=f'guided-{cid}-{docid}')
       if choice=='Nur d12–d88,9':
        st.info('Der d108-Sonderfall betrifft dieses Projekt damit nicht. Diese Prüfung kann abgeschlossen werden.')
       elif choice=='d108 ist ebenfalls verbaut':
        st.warning('d108 ist verbaut. Die Prüfung bleibt offen, bis die d108-spezifische Verarbeitung bzw. passende Unterlage eindeutig abgesichert ist.')
       else:
        st.info('Solange die Dimensionen nicht bekannt sind, bleibt die Prüfung offen.')
       if st.button('Prüfentscheidung speichern',key=f'guided-save-{cid}-{docid}',type='primary'):
        if choice=='Nur d12–d88,9': code='mapress_no_d108'; note='Im Projekt sind nur d12–d88,9 verbaut; der d108-Sonderfall ist nicht relevant.'; conf=1
        elif choice=='d108 ist ebenfalls verbaut': code='mapress_d108'; note='d108 ist im Projekt verbaut; d108-spezifische Verarbeitung/Unterlage ist noch abzusichern.'; conf=0
        else: code='mapress_unknown'; note='Verbaute Dimensionen sind noch nicht bekannt.'; conf=0
        con.execute('UPDATE documents SET project_confirmed=?,project_decision=?,project_decision_note=? WHERE id=?',(conf,code,note,docid)); con.commit(); st.rerun()
      elif is_rockwool800_proof:
       st.write('**Geführte Einbausituationsprüfung:** Wie wird ROCKWOOL 800 in diesem Projekt eingesetzt?')
       options=['Noch nicht bekannt','Normale technische Rohrdämmung – keine brandschutztechnische Funktion','Teil einer brandschutztechnischen Konstruktion / Abschottung / Durchführung','Andere oder gemischte Einbausituation']
       prior={'rw800_unknown':options[0],'rw800_standard':options[1],'rw800_fire':options[2],'rw800_other':options[3]}.get(decision,options[0])
       choice=st.radio('Einbausituation',options,index=options.index(prior),key=f'rw800-guided-{cid}-{docid}')
       if choice==options[1]:
        st.info('Für diese Projektangabe wird der allgemeine Prüfhaken „Anwendbarkeitsnachweise“ nicht als zusätzlich offener Standardnachweis behandelt. Die vorhandene Standardmappe bleibt maßgeblich.')
       elif choice==options[2]:
        st.warning('Brandschutztechnische Anwendung angegeben. Die Prüfung bleibt offen: Die konkrete Konstruktion, Bauteil-/Durchführungssituation und der dafür geltende Nachweis müssen projektbezogen zugeordnet werden.')
       elif choice==options[3]:
        st.warning('Die Einbausituation ist nicht eindeutig einer Standardanwendung zuzuordnen. Die Prüfung bleibt offen, bis die konkrete Anwendung geklärt ist.')
       else:
        st.info('Solange die Einbausituation nicht bekannt ist, bleibt die Prüfung offen.')
       if st.button('Einbausituation speichern',key=f'rw800-guided-save-{cid}-{docid}',type='primary'):
        if choice==options[1]: code='rw800_standard'; note='Normale technische Rohrdämmung ohne brandschutztechnische Funktion angegeben; allgemeiner Anwendbarkeits-Prüfhaken für dieses Projekt abgeschlossen.'; conf=1
        elif choice==options[2]: code='rw800_fire'; note='Brandschutztechnische Konstruktion/Abschottung/Durchführung angegeben; konkreter projektbezogener Nachweis ist noch zu klären.'; conf=0
        elif choice==options[3]: code='rw800_other'; note='Andere oder gemischte Einbausituation angegeben; konkrete Anwendung und Nachweisbedarf sind noch zu klären.'; conf=0
        else: code='rw800_unknown'; note='Einbausituation von ROCKWOOL 800 ist noch nicht bekannt.'; conf=0
        con.execute('UPDATE documents SET project_confirmed=?,project_decision=?,project_decision_note=? WHERE id=?',(conf,code,note,docid)); con.commit(); st.rerun()
      elif is_conlit_proof:
       st.write('**Geführte Einbausituationsprüfung für Conlit® 150 U**')
       st.caption('Mehrfachauswahl: Es werden nur Gruppen getrennt, wenn unterschiedliche relevante Nachweise gelten. Reine Varianten mit gleicher Dokumentation werden zusammengefasst.')
       labels=list(CONLIT_DOCUMENT_GROUPS)
       saved_codes=get_application_groups(con,cid)
       defaults=[label for label,cfg in CONLIT_DOCUMENT_GROUPS.items() if cfg['code'] in saved_codes]
       choices=st.multiselect('Welche dokumentationsrelevanten Einbausituationen kommen in diesem Projekt vor?',labels,default=defaults,key=f'conlit-multi-{cid}-{docid}')
       unknown=st.checkbox('Einbausituation noch nicht vollständig bekannt / weitere Situation möglich',value=(decision in ['conlit_unknown','conlit_other']),key=f'conlit-unknown-{cid}-{docid}')
       if choices:
        st.markdown('**Dafür werden folgende Hersteller-Nachweise benötigt:**')
        for label in choices:
         cfg=CONLIT_DOCUMENT_GROUPS[label]; st.write(f"• {label} → **{cfg['proof']}**")
       if unknown: st.warning('Solange weitere Einbausituationen möglich oder unbekannt sind, bleibt die Prüfung 🟡.')
       elif not choices: st.info('Bitte mindestens eine tatsächlich verbaute, dokumentationsrelevante Einbausituation auswählen.')
       else: st.info('Beim Speichern ordnet die App jeder Auswahl den offiziellen ROCKWOOL-Nachweis zu und versucht, die PDF direkt offline zu sichern.')
       if st.button('Einbausituationen speichern & Nachweise zuordnen',key=f'conlit-guided-save-{cid}-{docid}',type='primary'):
        codes=[CONLIT_DOCUMENT_GROUPS[x]['code'] for x in choices]; save_application_groups(con,cid,codes)
        if unknown or not choices:
         code='conlit_unknown' if not choices else 'conlit_other'; note='Einbausituation ist noch nicht vollständig bekannt.'; conf=0
         con.execute('UPDATE documents SET project_confirmed=?,project_decision=?,project_decision_note=? WHERE id=?',(conf,code,note,docid)); con.commit(); st.rerun()
        ok,errs=ensure_conlit_proofs(con,project,cid,m,p,choices)
        all_ok=(len(ok)==len(choices) and not errs)
        code='conlit_multi_complete' if all_ok else 'conlit_multi_open'
        note='Ausgewählte Dokumentgruppen: '+', '.join(CONLIT_DOCUMENT_GROUPS[x]['proof'] for x in choices)+('. Alle offiziellen Nachweise wurden offline zugeordnet.' if all_ok else '. Mindestens ein Nachweis konnte noch nicht offline verifiziert/zugeordnet werden.')
        con.execute('UPDATE documents SET project_confirmed=?,project_decision=?,project_decision_note=? WHERE id=?',(1 if all_ok else 0,code,note,docid)); con.commit()
        st.session_state[f'conlit-proof-report-{cid}']={'ok':len(ok),'total':len(choices),'errs':errs}; st.rerun()
      else:
       st.info('Für diesen Prüffall gibt es noch keine geführte Einbausituationsprüfung. Bitte nicht blind bestätigen; der konkrete Anwendungsfall sollte zuerst geklärt werden.')
    if confirmed_checks:
     st.markdown('### ✅ Bestätigte Projektprüfungen')
     for docid,dtype,title,url,dconf,path,dstatus,prio,confirmed,source_page,decision,decision_note in confirmed_checks:
      st.success(f'**{dtype}: {title}** · für dieses Projekt fachlich geprüft und bestätigt')
      if decision_note: st.caption(f'Prüfentscheidung: {decision_note}')
      if st.button('Prüfentscheidung zurücknehmen / ändern',key=f'unconfirm-{cid}-{docid}'):
       con.execute('UPDATE documents SET project_confirmed=0,project_decision="",project_decision_note="" WHERE id=?',(docid,)); con.commit(); st.rerun()


