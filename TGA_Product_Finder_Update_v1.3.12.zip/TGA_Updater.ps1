﻿param(
  [Parameter(Mandatory=$true)][string]$Package
)
$ErrorActionPreference = "Stop"
$root = Join-Path $env:LOCALAPPDATA "TGA Product Finder"
$appdir = Join-Path $root "App"
$temp = Join-Path $env:TEMP "TGA_Product_Finder_Standalone_Updater"
$log = Join-Path $root "updater.log"

"UPDATER GESTARTET: $(Get-Date -Format o)" | Out-File $log -Encoding utf8
"Package: $Package" | Add-Content $log

try {
    Write-Host ""
    Write-Host "TGA Product Finder - Windows-Updater"
    Write-Host "===================================="
    Write-Host "Update-Paket wird geprueft..."
    if (!(Test-Path -LiteralPath $Package)) {
        throw "Update-Paket nicht gefunden: $Package"
    }

    if (Test-Path $temp) { Remove-Item $temp -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    Expand-Archive -LiteralPath $Package -DestinationPath $temp -Force
    "ZIP entpackt." | Add-Content $log

    $newApp = Join-Path $temp "app.py"
    $newVer = Join-Path $temp "version.json"
    if (!(Test-Path $newApp)) { throw "app.py fehlt im Update-Paket." }
    if (!(Test-Path $appdir)) { throw "Installationsordner fehlt: $appdir" }

    Write-Host "Programmdateien werden aktualisiert..."
    Start-Sleep -Seconds 2
    Copy-Item $newApp (Join-Path $appdir "app.py") -Force
    if (Test-Path $newVer) {
        Copy-Item $newVer (Join-Path $appdir "version.json") -Force
    }

    $installed = Get-Content (Join-Path $appdir "app.py") -Raw
    if ($installed -notmatch 'APP_VERSION\s*=\s*"1\.3\.12"') {
        throw "Versionspruefung fehlgeschlagen: v1.3.11 wurde nicht gefunden."
    }

    "INSTALLATION ERFOLGREICH: $(Get-Date -Format o)" | Add-Content $log
    Write-Host ""
    Write-Host "Update erfolgreich installiert."
    Write-Host "TGA Product Finder wird neu gestartet..."

    $launcher = Join-Path $root "TGA Product Finder.bat"
    if (!(Test-Path $launcher)) { throw "Programmstarter fehlt: $launcher" }
    Start-Process -FilePath $launcher
    Start-Sleep -Seconds 2
}
catch {
    "FEHLER: $($_.Exception.Message)" | Add-Content $log
    Write-Host ""
    Write-Host "UPDATE FEHLGESCHLAGEN:"
    Write-Host $_.Exception.Message
    Write-Host ""
    Write-Host "Protokoll: $log"
    Read-Host "ENTER zum Schliessen"
    exit 1
}
