@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_INSTALLIEREN_v1.3.2.ps1"
pause
