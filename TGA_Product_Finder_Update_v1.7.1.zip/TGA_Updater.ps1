﻿param(
  [Parameter(Mandatory=$true)][string]$Package
)
$ErrorActionPreference = "Stop"
$root = Join-Path $env:LOCALAPPDATA "TGA Product Finder"
$appdir = Join-Path $root "App"
$temp = Join-Path $env:TEMP "TGA_Product_Finder_Standalone_Updater"
$log = Join-Path $root "updater.log"

"UPDATER GESTARTET: $(Get-Date -Format o)" | Out-File $log -Encoding utf8
"Package: $Package" | Add-Content $log

try {
    Write-Host ""
    Write-Host "TGA Product Finder - Windows-Updater"
    Write-Host "===================================="
    Write-Host "Update-Paket wird geprueft..."

    if (!(Test-Path -LiteralPath $Package)) { throw "Update-Paket nicht gefunden: $Package" }
    if (Test-Path $temp) { Remove-Item $temp -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    Expand-Archive -LiteralPath $Package -DestinationPath $temp -Force

    $newApp = Join-Path $temp "app.py"
    $newVer = Join-Path $temp "version.json"
    if (!(Test-Path $newApp)) { throw "app.py fehlt im Update-Paket." }
    if (!(Test-Path $newVer)) { throw "version.json fehlt im Update-Paket." }
    if (!(Test-Path $appdir)) { throw "Installationsordner fehlt: $appdir" }

    $targetInfo = Get-Content $newVer -Raw | ConvertFrom-Json
    $targetVersion = [string]$targetInfo.version
    if ([string]::IsNullOrWhiteSpace($targetVersion)) { throw "Zielversion fehlt in version.json." }
    "Zielversion: $targetVersion" | Add-Content $log

    Write-Host "Zielversion: v$targetVersion"
    Write-Host "Programmdateien werden aktualisiert..."
    Start-Sleep -Seconds 2
    Copy-Item $newApp (Join-Path $appdir "app.py") -Force
    Copy-Item $newVer (Join-Path $appdir "version.json") -Force

    $installedVerFile = Join-Path $appdir "version.json"
    $installedInfo = Get-Content $installedVerFile -Raw | ConvertFrom-Json
    $installedVersion = [string]$installedInfo.version
    if ($installedVersion -ne $targetVersion) {
        throw "Versionspruefung fehlgeschlagen: erwartet v$targetVersion, gefunden v$installedVersion."
    }

    "INSTALLATION ERFOLGREICH: v$installedVersion $(Get-Date -Format o)" | Add-Content $log
    Write-Host ""
    Write-Host "Update auf v$installedVersion erfolgreich installiert."
    Write-Host "TGA Product Finder wird neu gestartet..."

    $launcher = Join-Path $root "TGA Product Finder.bat"
    if (!(Test-Path $launcher)) { throw "Programmstarter fehlt: $launcher" }
    Start-Process -FilePath $launcher
    Start-Sleep -Seconds 2
}
catch {
    "FEHLER: $($_.Exception.Message)" | Add-Content $log
    Write-Host ""
    Write-Host "UPDATE FEHLGESCHLAGEN:"
    Write-Host $_.Exception.Message
    Write-Host ""
    Write-Host "Protokoll: $log"
    Read-Host "ENTER zum Schliessen"
    exit 1
}
