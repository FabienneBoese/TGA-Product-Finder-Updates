@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_INSTALLIEREN_v1.3.5.ps1"
