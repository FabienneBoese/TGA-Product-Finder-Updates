﻿param(
  [Parameter(Mandatory=$true)][string]$Package
)
$ErrorActionPreference = "Stop"
$root = Join-Path $env:LOCALAPPDATA "TGA Product Finder"
$appdir = Join-Path $root "App"
$temp = Join-Path $env:TEMP "TGA_Product_Finder_Standalone_Updater"
$log = Join-Path $root "updater.log"
"Updater start $(Get-Date) Package=$Package" | Out-File $log -Encoding utf8
try {
  if (!(Test-Path $Package)) { throw "Update-Paket nicht gefunden: $Package" }
  if (Test-Path $temp) { Remove-Item $temp -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $temp | Out-Null
  Expand-Archive -LiteralPath $Package -DestinationPath $temp -Force
  $newApp = Join-Path $temp "app.py"
  $newVer = Join-Path $temp "version.json"
  if (!(Test-Path $newApp)) { throw "app.py fehlt im Update-Paket." }
  Start-Sleep -Seconds 2
  Copy-Item $newApp (Join-Path $appdir "app.py") -Force
  if (Test-Path $newVer) { Copy-Item $newVer (Join-Path $appdir "version.json") -Force }
  "Update erfolgreich $(Get-Date)" | Add-Content $log
  $launcher = Join-Path $root "TGA Product Finder.bat"
  if (Test-Path $launcher) { Start-Process $launcher }
} catch {
  "FEHLER $(Get-Date): $($_.Exception.Message)" | Add-Content $log
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show("Update fehlgeschlagen:`n$($_.Exception.Message)`n`nProtokoll: $log","TGA Product Finder Update") | Out-Null
  exit 1
}
