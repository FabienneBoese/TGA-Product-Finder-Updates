﻿$ErrorActionPreference="Stop"
$root=Join-Path $env:LOCALAPPDATA "TGA Product Finder"
$appdir=Join-Path $root "App"
$src=Split-Path -Parent $MyInvocation.MyCommand.Path
Start-Sleep -Seconds 2
Copy-Item (Join-Path $src "app.py") (Join-Path $appdir "app.py") -Force
Copy-Item (Join-Path $src "version.json") (Join-Path $appdir "version.json") -Force
Copy-Item (Join-Path $src "TGA_Updater.ps1") (Join-Path $root "TGA_Updater.ps1") -Force
Write-Host "ERFOLG: Version 1.3.16 ist installiert."
$launcher=Join-Path $root "TGA Product Finder.bat"
if(Test-Path $launcher){Start-Process $launcher}
Read-Host "ENTER zum Schliessen"
