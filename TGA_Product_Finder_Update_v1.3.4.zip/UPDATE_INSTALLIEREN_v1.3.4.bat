@echo off
title TGA Product Finder Update v1.3.4
echo TGA Product Finder - Update v1.3.4
echo =================================
echo.
echo Windows-Installer wurde gestartet.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_INSTALLIEREN_v1.3.4.ps1"
if errorlevel 1 (
 echo.
 echo PowerShell meldete einen Fehler.
 pause
)
