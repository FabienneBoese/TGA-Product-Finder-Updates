﻿$ErrorActionPreference = "Stop"
$root = Join-Path $env:LOCALAPPDATA "TGA Product Finder"
$appdir = Join-Path $root "App"
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$log = Join-Path $src "install_v1.3.4.log"
"Start: $(Get-Date)" | Out-File $log -Encoding utf8
try {
 Write-Host ""
 Write-Host "TGA Product Finder - Update v1.3.4"
 Write-Host "================================="
 Write-Host "Installer wurde erfolgreich gestartet."
 Start-Sleep -Seconds 2
 if (!(Test-Path (Join-Path $src "app.py"))) { throw "app.py fehlt im Update-Paket." }
 if (!(Test-Path $appdir)) { New-Item -ItemType Directory -Force -Path $appdir | Out-Null }
 Copy-Item (Join-Path $src "app.py") (Join-Path $appdir "app.py") -Force
 Copy-Item (Join-Path $src "version.json") (Join-Path $appdir "version.json") -Force
 $installed = Get-Content (Join-Path $appdir "app.py") -Raw
 if ($installed -notmatch 'APP_VERSION\s*=\s*"1\.3\.4"') { throw "Versionspruefung fehlgeschlagen." }
 "ERFOLG: Version 1.3.4 installiert: $(Get-Date)" | Add-Content $log
 Write-Host ""
 Write-Host "ERFOLG: Version 1.3.4 ist installiert."
 Write-Host "Projektdaten wurden nicht veraendert."
 $launcher = Join-Path $root "TGA Product Finder.bat"
 if (Test-Path $launcher) { Start-Process $launcher }
} catch {
 "FEHLER: $($_.Exception.Message)" | Add-Content $log
 Write-Host ""
 Write-Host "FEHLER: $($_.Exception.Message)"
}
Write-Host ""
Read-Host "Druecke ENTER zum Schliessen"
